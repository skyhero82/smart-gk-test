import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Initialize Gemini client if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  try {
    aiClient = new GoogleGenAI({ apiKey });
  } catch (err) {
    console.warn('Failed to initialize GoogleGenAI with key:', err);
  }
}

// --- In-Memory & Local Persistent Store for Analytics, Admin Security, & Messages ---
const DATA_FILE = path.resolve(__dirname, 'admin_store.json');

interface FeedbackMessage {
  id: string;
  userId: string;
  userName: string;
  userContact?: string;
  message: string;
  questionRef?: string;
  timestamp: number;
  reply?: string;
  repliedAt?: number;
}

interface AdminStore {
  developerPin: string;
  analytics: {
    totalVisits: number;
    installsCount: number;
    totalQuizzesCompleted: number;
    totalQuestionsAnswered: number;
    devices: {
      android: number;
      ios: number;
      desktop: number;
    };
    uniqueVisitors: string[];
  };
  messages: FeedbackMessage[];
}

let store: AdminStore = {
  developerPin: '1234', // Default Master PIN (changeable in Admin Panel)
  analytics: {
    totalVisits: 84, // Initial baseline for realistic demo
    installsCount: 19,
    totalQuizzesCompleted: 142,
    totalQuestionsAnswered: 780,
    devices: {
      android: 58,
      ios: 18,
      desktop: 8,
    },
    uniqueVisitors: [],
  },
  messages: [
    {
      id: 'msg-sample-1',
      userId: 'user-sample',
      userName: 'राहुल कुमार (पटना)',
      userContact: 'rahul.gk@example.com',
      message: 'सर, क्या इसमें बिहार दरोगा और BPSC के पिछले 5 साल के प्रश्न भी जोड़े जा सकते हैं?',
      timestamp: Date.now() - 3600000 * 24,
      reply: 'हाँ राहुल, आप ऊपर "+ प्रश्न जोड़ें" से सीधे अपने नोट्स जोड़ सकते हैं, और हम भी नए अपडेट में BPSC प्रश्न बैंक शामिल कर रहे हैं!',
      repliedAt: Date.now() - 3600000 * 18,
    },
  ],
};

// Load saved data if exists
if (fs.existsSync(DATA_FILE)) {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    store = { ...store, ...JSON.parse(raw) };
  } catch (e) {
    console.warn('Could not read admin_store.json, using defaults.');
  }
}

function saveStore() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (e) {
    console.warn('Failed to persist admin_store.json');
  }
}

// --- Analytics Endpoints ---
app.post('/api/analytics/track', (req, res) => {
  const { type, visitorId, device = 'android' } = req.body;

  if (type === 'visit') {
    store.analytics.totalVisits += 1;
    if (visitorId && !store.analytics.uniqueVisitors.includes(visitorId)) {
      store.analytics.uniqueVisitors.push(visitorId);
    }
    const devKey = device.toLowerCase().includes('iphone') || device.toLowerCase().includes('ios')
      ? 'ios'
      : device.toLowerCase().includes('android')
      ? 'android'
      : 'desktop';
    store.analytics.devices[devKey] = (store.analytics.devices[devKey] || 0) + 1;
  } else if (type === 'install') {
    store.analytics.installsCount += 1;
  } else if (type === 'quiz_completed') {
    store.analytics.totalQuizzesCompleted += 1;
  } else if (type === 'question_answered') {
    store.analytics.totalQuestionsAnswered += 1;
  }

  saveStore();
  res.json({ success: true, count: store.analytics });
});

app.get('/api/analytics/stats', (req, res) => {
  res.json({
    success: true,
    stats: {
      ...store.analytics,
      uniqueUsersCount: Math.max(store.analytics.uniqueVisitors.length, Math.round(store.analytics.totalVisits * 0.65)),
    },
  });
});

// --- Master Developer PIN Authentication ---
app.post('/api/admin/login', (req, res) => {
  const { pin } = req.body;
  if (pin === store.developerPin) {
    res.json({ success: true, message: 'प्रमाणीकरण सफल! डेवलपर मोड सक्रिय है।' });
  } else {
    res.status(401).json({ success: false, message: 'गलत पासवर्ड / पिन! केवल अधिकृत डेवलपर के लिए।' });
  }
});

app.post('/api/admin/change-pin', (req, res) => {
  const { currentPin, newPin } = req.body;
  if (currentPin !== store.developerPin) {
    return res.status(401).json({ success: false, message: 'वर्तमान पासवर्ड गलत है!' });
  }
  if (!newPin || newPin.trim().length < 4) {
    return res.status(400).json({ success: false, message: 'नया पासवर्ड कम से कम 4 अक्षरों का होना चाहिए।' });
  }
  store.developerPin = newPin.trim();
  saveStore();
  res.json({ success: true, message: 'डेवलपर पासवर्ड सफलतापूर्वक बदल दिया गया!' });
});

// --- Feedback / Messaging Endpoints ---
app.post('/api/messages/send', (req, res) => {
  const { userId, userName, userContact, message, questionRef } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'मैसेज खाली नहीं हो सकता।' });
  }

  const newMsg: FeedbackMessage = {
    id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    userId: userId || 'anonymous',
    userName: userName?.trim() || 'अज्ञात छात्र (Student)',
    userContact: userContact?.trim() || '',
    message: message.trim(),
    questionRef: questionRef?.trim() || '',
    timestamp: Date.now(),
  };

  store.messages.unshift(newMsg);
  saveStore();
  res.json({ success: true, message: 'आपका संदेश डेवलपर को भेज दिया गया है!', msgId: newMsg.id });
});

app.get('/api/messages/all', (req, res) => {
  const pin = req.headers['x-admin-pin'];
  if (pin !== store.developerPin) {
    return res.status(401).json({ error: 'अनधिकृत पहुंच' });
  }
  res.json({ success: true, messages: store.messages });
});

app.post('/api/messages/reply', (req, res) => {
  const pin = req.headers['x-admin-pin'];
  if (pin !== store.developerPin) {
    return res.status(401).json({ error: 'अनधिकृत पहुंच' });
  }

  const { messageId, replyText } = req.body;
  const msg = store.messages.find((m) => m.id === messageId);
  if (!msg) {
    return res.status(404).json({ error: 'संदेश नहीं मिला' });
  }

  msg.reply = replyText.trim();
  msg.repliedAt = Date.now();
  saveStore();
  res.json({ success: true, message: 'रिप्लाई भेज दिया गया!', updatedMessage: msg });
});

app.get('/api/messages/user/:userId', (req, res) => {
  const { userId } = req.params;
  const userMessages = store.messages.filter((m) => m.userId === userId);
  res.json({ success: true, messages: userMessages });
});

// --- Direct Android Studio Source Code & APK Package Download ---
app.get('/api/download/SmartGKTest-Android-Source.zip', (req, res) => {
  const filePath = path.resolve(__dirname, 'public', 'SmartGKTest-Android-Source.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="SmartGKTest-Android-Project.zip"');
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.status(404).send('File not found');
  }
});

// --- Free Standalone APK Build Package / Direct Download Helper ---
app.get('/api/download-apk-info', (req, res) => {
  res.json({
    success: true,
    appName: 'Smart GK Test',
    packageName: 'com.smartgk.test',
    version: '1.0.0',
    directApkDownloadUrl: `${req.protocol}://${req.get('host')}/api/download/SmartGKTest.apk`,
    directPwaUrl: `${req.protocol}://${req.get('host')}`,
    manifestUrl: `${req.protocol}://${req.get('host')}/manifest.json`,
  });
});

// --- AI Endpoints ---
app.post('/api/generate-quiz', async (req, res) => {
  const { topic, difficulty = 'medium', language = 'bilingual', count = 5 } = req.body;

  if (!aiClient) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY not configured. Falling back to built-in question bank.',
      fallback: true,
    });
  }

  const prompt = `You are an expert General Knowledge (GK) educator and quiz master.
Generate exactly ${count} multiple choice questions (MCQ) on the topic: "${topic || 'General Knowledge India & World'}".
Difficulty level: ${difficulty} (easy / medium / hard).
Target Audience language requirement: ${language} (bilingual Hindi and English).

Return ONLY a valid JSON array of objects without markdown formatting:
[
  {
    "id": "gen-1",
    "category": "Custom Topic",
    "questionHi": "हिंदी में प्रश्न यहाँ लिखें?",
    "questionEn": "Write question in English here?",
    "optionsHi": ["विकल्प A", "विकल्प B", "विकल्प C", "विकल्प D"],
    "optionsEn": ["Option A", "Option B", "Option C", "Option D"],
    "correctIndex": 0,
    "explanationHi": "हिंदी में तथ्यपूर्ण व्याख्या...",
    "explanationEn": "Factual explanation in English...",
    "difficulty": "${difficulty}",
    "tag": "Exam GK"
  }
]`;

  try {
    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '[]';
    const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const questions = JSON.parse(cleaned);

    res.json({ success: true, questions });
  } catch (error: any) {
    console.error('Quiz generation error:', error);
    res.status(500).json({
      error: error.message || 'Failed to generate questions with AI.',
      fallback: true,
    });
  }
});

app.post('/api/explain-question', async (req, res) => {
  const { question, options, correctAnswer, userSelectedAnswer } = req.body;

  if (!aiClient) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY not configured.',
    });
  }

  const prompt = `You are a supportive, knowledgeable Indian GK teacher (गुरुजी).
Explain this GK question in simple Hindi and English:
Question: ${question}
Options: ${JSON.stringify(options)}
Correct Answer: ${correctAnswer}
User selected: ${userSelectedAnswer || 'None'}

Please provide:
1. Quick Concept / Fact: Why is this answer correct?
2. Historical or Scientific Background: 2 interesting trivia points.
3. Memory Trick / Mnemonic (याद रखने की ट्रिक): A simple trick to remember this fact forever for exams.`;

  try {
    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    res.json({ success: true, explanation: response.text });
  } catch (error: any) {
    console.error('AI Explanation error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate explanation.' });
  }
});

// Vite middleware in dev or static files in prod
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
