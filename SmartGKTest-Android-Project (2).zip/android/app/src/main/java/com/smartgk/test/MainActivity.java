package com.smartgk.test;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
