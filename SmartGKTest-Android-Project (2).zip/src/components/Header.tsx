import React from 'react';
import { Volume2, VolumeX, Flame, Bookmark, AlertCircle, Sparkles, Smartphone, PlusCircle, Play, ShieldCheck, MessageSquare } from 'lucide-react';
import { LanguageMode, UserStats } from '../types/quiz';
import { sounds } from '../utils/audio';

interface HeaderProps {
  stats: UserStats;
  languageMode: LanguageMode;
  onLanguageChange: (lang: LanguageMode) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenSavedModal: (tab: 'bookmarks' | 'mistakes') => void;
  onOpenAiModal: () => void;
  onOpenInstallModal: () => void;
  onOpenAddQuestionModal: () => void;
  onOpenPlayStoreGuide: () => void;
  onOpenAdminDashboard: () => void;
  onOpenContactModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  languageMode,
  onLanguageChange,
  soundEnabled,
  onToggleSound,
  onOpenSavedModal,
  onOpenAiModal,
  onOpenInstallModal,
  onOpenAddQuestionModal,
  onOpenPlayStoreGuide,
  onOpenAdminDashboard,
  onOpenContactModal,
}) => {
  const accuracy = stats.totalAnswered > 0
    ? Math.round((stats.correctAnswers / stats.totalAnswered) * 100)
    : 0;

  return (
    <header className="border-b border-slate-200 bg-white/95 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-5xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-lg shadow-sm shadow-amber-200">
            GK
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-slate-900 leading-none">
                Smart GK Test
              </h1>
              <span className="text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-1.5 py-0.5 rounded">
                स्मार्ट क्विज़
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5 hidden sm:block">
              अनलिमिटेड सामान्य ज्ञान क्विज़ एवं प्रतियोगी परीक्षा तैयारी
            </p>
          </div>
        </div>

        {/* Live stats */}
        <div className="flex items-center gap-4 text-xs font-medium text-slate-600">
          {/* Streak */}
          <div className="flex items-center gap-1.5" title="लगातार सही उत्तर (Streak)">
            <Flame className={`w-4 h-4 ${stats.currentStreak > 0 ? 'text-amber-500 fill-amber-500 animate-bounce' : 'text-slate-400'}`} />
            <span className="font-bold text-slate-800 font-mono text-sm">{stats.currentStreak}</span>
            <span className="text-slate-400 text-[11px] hidden md:inline">लगातार</span>
          </div>

          <span className="text-slate-200">|</span>

          {/* Accuracy */}
          <div className="flex items-center gap-1" title="सटीकता प्रतिशत">
            <span className="text-slate-400 text-[11px]">सटीकता:</span>
            <span className="font-bold text-emerald-600 font-mono text-sm">{accuracy}%</span>
          </div>

          <span className="text-slate-200">|</span>

          {/* Points/Score */}
          <div className="flex items-center gap-1" title="कुल अर्जित अंक">
            <span className="text-slate-400 text-[11px]">अंक:</span>
            <span className="font-bold text-amber-600 font-mono text-sm">{stats.coins}</span>
          </div>
        </div>

        {/* Controls: Language, Sound, AI, Bookmarks */}
        <div className="flex items-center gap-2">
          {/* Language toggle */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs font-medium border border-slate-200/80">
            <button
              onClick={() => {
                sounds.playClick();
                onLanguageChange('hi');
              }}
              className={`px-2 py-1 rounded transition-colors ${
                languageMode === 'hi' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="हिंदी में देखें"
            >
              हिं
            </button>
            <button
              onClick={() => {
                sounds.playClick();
                onLanguageChange('en');
              }}
              className={`px-2 py-1 rounded transition-colors ${
                languageMode === 'en' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="View in English"
            >
              EN
            </button>
            <button
              onClick={() => {
                sounds.playClick();
                onLanguageChange('bilingual');
              }}
              className={`px-2 py-1 rounded transition-colors ${
                languageMode === 'bilingual' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
              title="दोनों भाषाएँ (द्विभाषी)"
            >
              दोनों
            </button>
          </div>

          {/* AI Custom Quiz Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenAiModal();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg transition-colors"
            title="किसी भी टॉपिक पर नया क्विज़ बनाएं"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span className="hidden sm:inline">AI जनरेटर</span>
          </button>

          {/* Add Custom Question Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenAddQuestionModal();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
            title="अपने अध्ययन नोट्स से नए प्रश्न जोड़ें"
          >
            <PlusCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden sm:inline">+ प्रश्न जोड़ें</span>
          </button>

          {/* Play Store & APK Guide Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenPlayStoreGuide();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors"
            title="Play Store पब्लिश और APK डाउनलोड गाइड"
          >
            <Play className="w-3.5 h-3.5 text-indigo-600 fill-indigo-600" />
            <span className="hidden sm:inline">Play Store / APK</span>
          </button>

          {/* Contact Developer / Help Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenContactModal();
            }}
            className="flex items-center gap-1.5 px-2 py-1.5 text-xs font-semibold text-sky-800 bg-sky-50 hover:bg-sky-100 border border-sky-200 rounded-lg transition-colors"
            title="संदेह या संदेश डेवलपर को भेजें"
          >
            <MessageSquare className="w-3.5 h-3.5 text-sky-600" />
            <span className="hidden sm:inline">मैसेज</span>
          </button>

          {/* Master Admin / Developer Dashboard */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenAdminDashboard();
            }}
            className="flex items-center gap-1.5 px-2 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors"
            title="डेवलपर कंट्रोल रूम (पासवर्ड प्रोटेक्टेड)"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
            <span>एडमिन</span>
          </button>

          {/* Get App / Install Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenInstallModal();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-lg transition-colors shadow-xs"
            title="ऐप लिंक व फोन में इंस्टॉल करें"
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-600" />
            <span>ऐप लें</span>
          </button>

          {/* Bookmarks */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenSavedModal('bookmarks');
            }}
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative"
            title="सहेजे गए प्रश्न (Bookmarks)"
          >
            <Bookmark className="w-4 h-4" />
            {stats.bookmarks.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white rounded-full text-[10px] flex items-center justify-center font-bold">
                {stats.bookmarks.length}
              </span>
            )}
          </button>

          {/* Mistakes review */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenSavedModal('mistakes');
            }}
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative"
            title="गलत उत्तरों की समीक्षा (Mistakes Bank)"
          >
            <AlertCircle className="w-4 h-4 text-rose-500" />
            {stats.mistakes.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] flex items-center justify-center font-bold">
                {stats.mistakes.length}
              </span>
            )}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
            title={soundEnabled ? 'ध्वनि बंद करें' : 'ध्वनि चालू करें'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-600" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>
        </div>
      </div>
    </header>
  );
};
