import React, { useState, useEffect } from 'react';
import {
  Bookmark,
  CheckCircle2,
  XCircle,
  Sparkles,
  ArrowRight,
  HelpCircle,
  Users,
  Scissors,
  FastForward,
  RotateCcw,
  Check,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { LanguageMode, Question } from '../types/quiz';
import { sounds } from '../utils/audio';

interface QuizCardProps {
  question: Question;
  questionNumber: number;
  totalQuestions?: number;
  languageMode: LanguageMode;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onAnswerSelected: (selectedIndex: number, isCorrect: boolean) => void;
  onNextQuestion: () => void;
  onSkipQuestion: () => void;
  onOpenAudiencePoll: () => void;
  onOpenAiGuru: () => void;
  autoAdvanceEnabled: boolean;
  onToggleAutoAdvance: () => void;
  mode: string;
}

export const QuizCard: React.FC<QuizCardProps> = ({
  question,
  questionNumber,
  totalQuestions,
  languageMode,
  isBookmarked,
  onToggleBookmark,
  onAnswerSelected,
  onNextQuestion,
  onSkipQuestion,
  onOpenAudiencePoll,
  onOpenAiGuru,
  autoAdvanceEnabled,
  onToggleAutoAdvance,
  mode,
}) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [hasAnswered, setHasAnswered] = useState<boolean>(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<number[]>([]);
  const [usedFiftyFifty, setUsedFiftyFifty] = useState<boolean>(false);
  const [usedAudiencePoll, setUsedAudiencePoll] = useState<boolean>(false);
  const [showExplanation, setShowExplanation] = useState<boolean>(true);

  // Reset state when active question changes
  useEffect(() => {
    setSelectedOption(null);
    setHasAnswered(false);
    setEliminatedOptions([]);
    setUsedFiftyFifty(false);
    setUsedAudiencePoll(false);
    setShowExplanation(true);
  }, [question.id]);

  // Auto advance timer
  useEffect(() => {
    if (hasAnswered && autoAdvanceEnabled) {
      const timer = setTimeout(() => {
        onNextQuestion();
      }, 2400);
      return () => clearTimeout(timer);
    }
  }, [hasAnswered, autoAdvanceEnabled, onNextQuestion]);

  // Handle Option Click
  const handleSelectOption = (idx: number) => {
    if (hasAnswered || eliminatedOptions.includes(idx)) return;

    setSelectedOption(idx);
    setHasAnswered(true);

    const isCorrect = idx === question.correctIndex;
    if (isCorrect) {
      sounds.playCorrect();
    } else {
      sounds.playWrong();
    }

    onAnswerSelected(idx, isCorrect);
  };

  // 50:50 Lifeline
  const handleFiftyFifty = () => {
    if (usedFiftyFifty || hasAnswered) return;
    sounds.playClick();
    setUsedFiftyFifty(true);

    const correct = question.correctIndex;
    const wrongOptions = [0, 1, 2, 3].filter(i => i !== correct);
    // Shuffle and pick 2 to eliminate
    const shuffled = wrongOptions.sort(() => Math.random() - 0.5);
    setEliminatedOptions([shuffled[0], shuffled[1]]);
  };

  // Audience poll trigger
  const handleAudiencePollClick = () => {
    if (usedAudiencePoll) return;
    sounds.playClick();
    setUsedAudiencePoll(true);
    onOpenAudiencePoll();
  };

  const optionLetters = ['A', 'B', 'C', 'D'];

  // Determine question texts based on languageMode
  const showHi = languageMode === 'hi' || languageMode === 'bilingual';
  const showEn = languageMode === 'en' || languageMode === 'bilingual';

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm p-5 sm:p-7 space-y-6 relative transition-all">
      {/* Top Question Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
            प्रश्न {questionNumber} {totalQuestions ? `/ ${totalQuestions}` : ''}
          </span>
          <span className="text-xs text-slate-500 font-medium">
            {question.category}
          </span>
          {question.tag && (
            <>
              <span className="text-slate-300">·</span>
              <span className="text-xs text-slate-400 font-normal">{question.tag}</span>
            </>
          )}
        </div>

        {/* Lifelines & Bookmark Controls */}
        <div className="flex items-center gap-1.5">
          {/* 50:50 Lifeline */}
          <button
            onClick={handleFiftyFifty}
            disabled={usedFiftyFifty || hasAnswered}
            className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg border transition-all ${
              usedFiftyFifty
                ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
                : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
            }`}
            title="50:50 - दो गलत विकल्प हटाएं"
          >
            <Scissors className="w-3.5 h-3.5" />
            <span>50:50</span>
          </button>

          {/* Audience Poll Lifeline */}
          <button
            onClick={handleAudiencePollClick}
            disabled={usedAudiencePoll || hasAnswered}
            className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg border transition-all ${
              usedAudiencePoll
                ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
                : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
            }`}
            title="जनमत पोल"
          >
            <Users className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">पोल</span>
          </button>

          {/* Skip Button */}
          {!hasAnswered && (
            <button
              onClick={() => {
                sounds.playClick();
                onSkipQuestion();
              }}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              title="यह प्रश्न छोड़ें"
            >
              <FastForward className="w-3.5 h-3.5" />
              <span>स्किप</span>
            </button>
          )}

          {/* Bookmark Button */}
          <button
            onClick={() => {
              sounds.playClick();
              onToggleBookmark(question.id);
            }}
            className={`p-1.5 rounded-lg border transition-colors ${
              isBookmarked
                ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                : 'text-slate-400 hover:text-slate-700 bg-white border-slate-200'
            }`}
            title={isBookmarked ? 'बुकमार्क हटाया' : 'प्रश्न सहेजें'}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
        </div>
      </div>

      {/* Question Prompt */}
      <div className="space-y-1.5">
        {showHi && (
          <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
            {question.questionHi}
          </h2>
        )}
        {showEn && (
          <p className="text-sm font-medium text-slate-600 leading-relaxed">
            {question.questionEn}
          </p>
        )}
      </div>

      {/* 4 Interactive Option Buttons - Mobile Stack */}
      <div className="flex flex-col gap-2.5 pt-1">
        {[0, 1, 2, 3].map((idx) => {
          const isEliminated = eliminatedOptions.includes(idx);
          const isSelected = selectedOption === idx;
          const isCorrect = idx === question.correctIndex;

          let btnStyle = 'border-slate-200/90 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800 shadow-2xs';
          let letterBadge = 'bg-slate-100 text-slate-700 border-slate-200';

          if (isEliminated) {
            btnStyle = 'opacity-30 cursor-not-allowed bg-slate-50 border-slate-200 text-slate-400 line-through';
          } else if (hasAnswered) {
            if (isCorrect) {
              btnStyle = 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold ring-2 ring-emerald-500/20';
              letterBadge = 'bg-emerald-600 text-white border-emerald-600';
            } else if (isSelected && !isCorrect) {
              btnStyle = 'border-rose-400 bg-rose-50 text-rose-950 ring-2 ring-rose-400/20';
              letterBadge = 'bg-rose-500 text-white border-rose-500';
            } else {
              btnStyle = 'border-slate-200 bg-slate-50/60 opacity-60 text-slate-600';
            }
          }

          return (
            <button
              key={idx}
              disabled={hasAnswered || isEliminated}
              onClick={() => handleSelectOption(idx)}
              className={`text-left p-3.5 sm:p-4 rounded-xl border transition-all flex items-start gap-3 select-none ${btnStyle} ${
                !hasAnswered && !isEliminated ? 'cursor-pointer active:scale-[0.99]' : ''
              }`}
            >
              <span
                className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center shrink-0 border ${letterBadge} mt-0.5`}
              >
                {hasAnswered && isCorrect ? (
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                ) : (
                  optionLetters[idx]
                )}
              </span>

              <div className="flex-1 space-y-0.5 min-w-0">
                {showHi && (
                  <p className="text-sm font-medium leading-snug break-words">
                    {question.optionsHi[idx]}
                  </p>
                )}
                {showEn && languageMode === 'bilingual' && (
                  <p className="text-xs text-slate-500 leading-tight break-words">
                    {question.optionsEn[idx]}
                  </p>
                )}
                {languageMode === 'en' && !showHi && (
                  <p className="text-sm font-medium leading-snug break-words">
                    {question.optionsEn[idx]}
                  </p>
                )}
              </div>

              {hasAnswered && isSelected && (
                <div className="shrink-0 mt-0.5">
                  {isCorrect ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-500" />
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Answer Outcome & Explanation Accordion */}
      {hasAnswered && (
        <div className="pt-2 space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {selectedOption === question.correctIndex ? (
                  <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100/90 px-2.5 py-1 rounded-md">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    शानदार! सही उत्तर (+10 अंक)
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5 text-xs font-bold text-rose-700 bg-rose-100/90 px-2.5 py-1 rounded-md">
                    <XCircle className="w-4 h-4 text-rose-600" />
                    गलत उत्तर (सही विकल्प: {optionLetters[question.correctIndex]})
                  </span>
                )}
              </div>

              {/* Ask AI Guru Button */}
              <button
                onClick={() => {
                  sounds.playClick();
                  onOpenAiGuru();
                }}
                className="flex items-center gap-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-3 py-1.5 rounded-lg transition-colors"
                title="AI गुरु से इस प्रश्न की ट्रिक और व्याख्या समझें"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                <span>AI गुरु से समझें</span>
              </button>
            </div>

            {/* Explanation Prose */}
            <div className="text-xs text-slate-700 space-y-1.5 pt-1">
              <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                <span>तथ्यपूर्ण व्याख्या (Fact & Explanation):</span>
              </p>
              <p className="leading-relaxed text-slate-600">
                {question.explanationHi}
              </p>
              {languageMode === 'bilingual' && (
                <p className="leading-relaxed text-slate-500 pt-1 text-[11px] border-t border-slate-200/50">
                  {question.explanationEn}
                </p>
              )}
            </div>
          </div>

          {/* Action Row: Auto Advance & Next Button */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={autoAdvanceEnabled}
                onChange={onToggleAutoAdvance}
                className="rounded border-slate-300 text-amber-500 focus:ring-amber-400 w-3.5 h-3.5"
              />
              <span>स्वतः अगला प्रश्न लाएं (Auto Next)</span>
            </label>

            <button
              onClick={() => {
                sounds.playClick();
                onNextQuestion();
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl shadow-xs transition-all active:scale-[0.98] ml-auto"
            >
              <span>अगला प्रश्न (Next Question)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
