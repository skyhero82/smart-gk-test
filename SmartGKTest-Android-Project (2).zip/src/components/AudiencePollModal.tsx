import React, { useMemo } from 'react';
import { Users, X } from 'lucide-react';
import { Question } from '../types/quiz';

interface AudiencePollModalProps {
  question: Question;
  hiddenOptions: number[];
  onClose: () => void;
}

export const AudiencePollModal: React.FC<AudiencePollModalProps> = ({
  question,
  hiddenOptions,
  onClose,
}) => {
  // Generate realistic poll distribution
  const percentages = useMemo(() => {
    const p = [0, 0, 0, 0];
    const correct = question.correctIndex;

    // Remaining available options
    const available = [0, 1, 2, 3].filter(idx => !hiddenOptions.includes(idx));

    // Audience favors correct answer with 62-78%
    const correctPct = Math.floor(62 + Math.random() * 16);
    let remainingPct = 100 - correctPct;

    p[correct] = correctPct;

    const wrongAvailable = available.filter(idx => idx !== correct);
    wrongAvailable.forEach((optIdx, i) => {
      if (i === wrongAvailable.length - 1) {
        p[optIdx] = remainingPct;
      } else {
        const share = Math.floor(Math.random() * (remainingPct - (wrongAvailable.length - i)));
        p[optIdx] = share;
        remainingPct -= share;
      }
    });

    return p;
  }, [question, hiddenOptions]);

  const optionLetters = ['A', 'B', 'C', 'D'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 text-indigo-700 font-bold">
            <Users className="w-5 h-5" />
            <span>जनमत पोल (Audience Poll)</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-500 mt-2 mb-6">
          सर्वेक्षण के अनुसार दर्शकों के उत्तरों का प्रतिशत:
        </p>

        {/* Bar chart */}
        <div className="space-y-3.5">
          {[0, 1, 2, 3].map(idx => {
            const isEliminated = hiddenOptions.includes(idx);
            const pct = isEliminated ? 0 : percentages[idx];
            return (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                  <div className="flex items-center gap-2 truncate pr-2">
                    <span className="w-5 h-5 rounded-md bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center text-[11px] font-bold">
                      {optionLetters[idx]}
                    </span>
                    <span className={`truncate ${isEliminated ? 'line-through text-slate-300' : ''}`}>
                      {question.optionsHi[idx]}
                    </span>
                  </div>
                  <span className="font-mono text-indigo-600 font-bold">{pct}%</span>
                </div>

                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-700 ${
                      idx === question.correctIndex ? 'bg-indigo-600' : 'bg-slate-400'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            समझ गया, उत्तर चुनें
          </button>
        </div>
      </div>
    </div>
  );
};
