import React from 'react';
import { Flame, Bookmark, AlertCircle, Volume2, VolumeX, Sparkles, Smartphone, ShieldCheck, MessageSquare } from 'lucide-react';
import { LanguageMode, UserStats } from '../types/quiz';
import { sounds } from '../utils/audio';

interface MobileTopBarProps {
  stats: UserStats;
  languageMode: LanguageMode;
  onLanguageChange: (lang: LanguageMode) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenSavedModal: (tab: 'bookmarks' | 'mistakes') => void;
  onOpenInstallModal: () => void;
  onOpenContactModal: () => void;
  onOpenAiModal: () => void;
}

export const MobileTopBar: React.FC<MobileTopBarProps> = ({
  stats,
  languageMode,
  onLanguageChange,
  soundEnabled,
  onToggleSound,
  onOpenSavedModal,
  onOpenInstallModal,
  onOpenContactModal,
  onOpenAiModal,
}) => {
  return (
    <header className="bg-amber-500 text-white px-3.5 py-2.5 shrink-0 shadow-md sticky top-0 z-40 select-none">
      {/* Top Row: App Brand & Quick Action Chips */}
      <div className="flex items-center justify-between gap-2">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-white text-amber-600 flex items-center justify-center font-extrabold text-sm shadow-xs">
            GK
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm tracking-tight leading-none">
                Smart GK
              </span>
              <span className="text-[10px] font-bold bg-amber-600/90 text-amber-100 px-1.5 py-0.2 rounded-md">
                TEST
              </span>
            </div>
            <span className="text-[10px] text-amber-100/90 font-medium block leading-tight">
              स्मार्ट सामान्य ज्ञान
            </span>
          </div>
        </div>

        {/* Live Metrics: Streak & Coins */}
        <div className="flex items-center gap-2">
          {/* Streak */}
          <div className="flex items-center gap-1 bg-amber-600/70 border border-amber-400/40 px-2 py-0.8 rounded-lg text-xs font-bold shadow-xs">
            <Flame className={`w-3.5 h-3.5 ${stats.currentStreak > 0 ? 'text-amber-200 fill-amber-200 animate-bounce' : 'text-amber-300'}`} />
            <span className="font-mono text-xs">{stats.currentStreak}</span>
          </div>

          {/* Points */}
          <div className="flex items-center gap-1 bg-amber-600/70 border border-amber-400/40 px-2 py-0.8 rounded-lg text-xs font-bold shadow-xs">
            <span className="text-amber-200 text-[10px]">⭐</span>
            <span className="font-mono text-xs">{stats.coins}</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="p-1 rounded-lg bg-amber-600/60 hover:bg-amber-600 text-white transition-colors"
            title={soundEnabled ? 'ध्वनि बंद करें' : 'ध्वनि चालू करें'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-white" /> : <VolumeX className="w-3.5 h-3.5 text-amber-300" />}
          </button>
        </div>
      </div>

      {/* Second Row: Language switcher, AI generator, Bookmarks, Help */}
      <div className="flex items-center justify-between gap-1.5 pt-2 mt-1.5 border-t border-amber-400/30 text-xs">
        {/* Language Tabs */}
        <div className="flex items-center bg-amber-600/70 p-0.5 rounded-lg border border-amber-400/40 text-[11px] font-semibold">
          <button
            onClick={() => {
              sounds.playClick();
              onLanguageChange('hi');
            }}
            className={`px-2 py-0.5 rounded transition-all ${
              languageMode === 'hi' ? 'bg-white text-amber-900 shadow-xs' : 'text-amber-100 hover:text-white'
            }`}
          >
            हिं
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onLanguageChange('en');
            }}
            className={`px-2 py-0.5 rounded transition-all ${
              languageMode === 'en' ? 'bg-white text-amber-900 shadow-xs' : 'text-amber-100 hover:text-white'
            }`}
          >
            EN
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onLanguageChange('bilingual');
            }}
            className={`px-2 py-0.5 rounded transition-all ${
              languageMode === 'bilingual' ? 'bg-white text-amber-900 shadow-xs' : 'text-amber-100 hover:text-white'
            }`}
          >
            दोनों
          </button>
        </div>

        {/* Quick Icon Actions */}
        <div className="flex items-center gap-1.5">
          {/* AI Generator */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenAiModal();
            }}
            className="flex items-center gap-1 bg-purple-600/90 hover:bg-purple-600 text-white px-2 py-0.8 rounded-lg text-[11px] font-bold shadow-xs border border-purple-400/40"
          >
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>AI प्रश्न</span>
          </button>

          {/* Bookmarks */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenSavedModal('bookmarks');
            }}
            className="p-1 rounded-lg bg-amber-600/60 hover:bg-amber-600 text-white relative transition-colors"
            title="सहेजे गए प्रश्न"
          >
            <Bookmark className="w-3.5 h-3.5" />
            {stats.bookmarks.length > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 text-white rounded-full text-[9px] flex items-center justify-center font-bold">
                {stats.bookmarks.length}
              </span>
            )}
          </button>

          {/* Contact / Doubt */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenContactModal();
            }}
            className="p-1 rounded-lg bg-amber-600/60 hover:bg-amber-600 text-white transition-colors"
            title="मैसेज भेजें"
          >
            <MessageSquare className="w-3.5 h-3.5" />
          </button>

          {/* APK Install button */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenInstallModal();
            }}
            className="flex items-center gap-1 bg-white text-amber-900 px-2 py-0.8 rounded-lg text-[11px] font-bold shadow-xs"
          >
            <Smartphone className="w-3 h-3 text-amber-600" />
            <span>APK</span>
          </button>
        </div>
      </div>
    </header>
  );
};
