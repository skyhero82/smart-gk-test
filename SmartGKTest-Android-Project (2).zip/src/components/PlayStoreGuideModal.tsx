import React, { useState } from 'react';
import { X, Play, Download, Smartphone, Check, ExternalLink, Globe, ShieldCheck, ArrowRight, Copy } from 'lucide-react';
import { sounds } from '../utils/audio';

interface PlayStoreGuideModalProps {
  onClose: () => void;
}

export const PlayStoreGuideModal: React.FC<PlayStoreGuideModalProps> = ({ onClose }) => {
  const [copiedUrl, setCopiedUrl] = useState(false);
  const appUrl = window.location.href;
  const pwabuilderUrl = `https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`;

  const handleCopy = () => {
    sounds.playClick();
    navigator.clipboard.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
              APK
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-none">
                APK डाउनलोड और Google Play Store गाइड
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                ऐप को Android APK में बदलने और Play Store पर लाइव करने के चरण
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
          {/* Section 1: Android Studio Project Package (100% Genuine APK Builder) */}
          <div className="p-4 bg-emerald-50/70 border border-emerald-300 rounded-xl space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-emerald-950 text-sm flex items-center gap-1.5">
                <Download className="w-4 h-4 text-emerald-700" />
                <span>1. Android Studio प्रोजेक्ट ZIP डाउनलोड करें:</span>
              </span>
              <span className="text-[10px] bg-emerald-600 text-white font-extrabold px-2 py-0.5 rounded-full uppercase">
                Ready to Build
              </span>
            </div>

            <p className="text-slate-600 leading-relaxed text-xs">
              हमने आपके लिए पूरा असली <strong>Android Native (Capacitor + Gradle) प्रोजेक्ट</strong> तैयार कर दिया है। नीचे बटन दबाकर प्रोजेक्ट की ZIP फ़ाइल डाउनलोड करें:
            </p>

            <a
              href="/api/download/SmartGKTest-Android-Source.zip"
              download="SmartGKTest-Android-Project.zip"
              onClick={() => sounds.playCorrect()}
              className="flex items-center justify-center gap-2 w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>SmartGKTest-Android-Project.zip डाउनलोड करें (607 KB)</span>
            </a>

            <div className="bg-white p-2.5 rounded-lg border border-emerald-200/80 space-y-1 text-[11px] text-slate-600">
              <p className="font-semibold text-slate-800">APK बनाने के 3 आसान स्टेप्स:</p>
              <p>1. डाउनलोड की गई ZIP को अनजिप करें और <strong>Android Studio</strong> में खोलें।</p>
              <p>2. मेनू में <strong>Build ➔ Build Bundle(s) / APK(s) ➔ Build APK(s)</strong> पर क्लिक करें।</p>
              <p>3. 1 मिनट में आपकी असली, सर्टिफाइड <strong>`app-debug.apk`</strong> तैयार हो जाएगी जो हर फ़ोन में चलेगी!</p>
            </div>
          </div>

          {/* Section 2: Play Store Publishing Steps */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Globe className="w-4 h-4 text-indigo-600" />
              <span>2. Google Play Store पर ऐप पब्लिश करने के 4 आसान चरण:</span>
            </h4>

            <div className="space-y-2.5 pl-1">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  1
                </span>
                <div>
                  <p className="font-semibold text-slate-800">Google Play Console खाता बनाएं:</p>
                  <p className="text-slate-500 text-[11px]">
                    <a href="https://play.google.com/console" target="_blank" rel="noreferrer" className="text-indigo-600 underline">play.google.com/console</a> पर जाएं। Google इसके लिए $25 (लगभग ₹2,100) की वन-टाइम लाइफटाइम फीस लेता है।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  2
                </span>
                <div>
                  <p className="font-semibold text-slate-800">ऐप विवरण दर्ज करें (Store Listing):</p>
                  <p className="text-slate-500 text-[11px]">
                    ऐप का नाम (Smart GK Test), विवरण, 512x512 का आइकन (जो ऐप में बना है) और 2-3 स्क्रीनशॉट अपलोड करें।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  3
                </span>
                <div>
                  <p className="font-semibold text-slate-800">App Bundle (.aab) अपलोड करें:</p>
                  <p className="text-slate-500 text-[11px]">
                    PWABuilder से डाउनलोड की गई <strong>.aab</strong> फाइल को Play Console के 'Production' या 'Closed Testing' टैब में अपलोड करें।
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  4
                </span>
                <div>
                  <p className="font-semibold text-slate-800">सबमिट करें और रिव्यू (2-3 दिन):</p>
                  <p className="text-slate-500 text-[11px]">
                    Google Play टीम ऐप की जांच करेगी और 2 से 3 दिनों के भीतर आपका ऐप दुनिया भर के यूजर्स के लिए Play Store पर लाइव हो जाएगा!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Direct Phone Usage without Play Store */}
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1.5">
            <span className="font-bold text-amber-900 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-amber-700" />
              <span>बिना Play Store के भी फोन में चला सकते हैं:</span>
            </span>
            <p className="text-slate-600 text-[11px]">
              आप अपने दोस्तों, छात्रों या खुद के मोबाइल में Chrome खोलकर <strong>"Add to Home screen"</strong> कर सकते हैं। यह बिल्कुल असली APK ऐप की तरह बिना ब्राउज़र बार के फुल स्क्रीन में काम करता है।
            </p>
            <div className="pt-1 flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="flex-1 bg-white border border-amber-200 rounded px-2 py-1 text-[11px] font-mono truncate"
              />
              <button
                onClick={handleCopy}
                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-medium text-[11px] shrink-0"
              >
                {copiedUrl ? 'कॉपी हो गया' : 'लिंक कॉपी'}
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs transition-colors"
          >
            समझ गया, धन्यवाद
          </button>
        </div>
      </div>
    </div>
  );
};
