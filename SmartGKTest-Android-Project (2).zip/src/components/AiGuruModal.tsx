import React, { useState, useEffect } from 'react';
import { Sparkles, X, BrainCircuit, Lightbulb, BookOpen, Loader2 } from 'lucide-react';
import { Question } from '../types/quiz';

interface AiGuruModalProps {
  question: Question;
  selectedOptionIndex: number | null;
  onClose: () => void;
}

export const AiGuruModal: React.FC<AiGuruModalProps> = ({
  question,
  selectedOptionIndex,
  onClose,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [explanation, setExplanation] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    async function fetchAiExplanation() {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch('/api/explain-question', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: `${question.questionHi} (${question.questionEn})`,
            options: question.optionsHi,
            correctAnswer: question.optionsHi[question.correctIndex],
            userSelectedAnswer: selectedOptionIndex !== null ? question.optionsHi[selectedOptionIndex] : null,
          }),
        });

        const data = await res.json();
        if (isMounted) {
          if (data.success && data.explanation) {
            setExplanation(data.explanation);
          } else {
            // High quality fallback
            setExplanation(
              `💡 **मूल तथ्य**: ${question.explanationHi}\n\n📚 **विस्तार**: यह प्रश्न ${question.category} के महत्वपूर्ण विषयों से संबंधित है। प्रतियोगी परीक्षाओं में ऐसे प्रश्न अक्सर पूछे जाते हैं।\n\n🎯 **स्मार्ट ट्रिक**: सही उत्तर '${question.optionsHi[question.correctIndex]}' को इसके मुख्य कीवर्ड '${question.tag || question.category}' के साथ जोड़कर याद रखें।`
            );
          }
        }
      } catch (err) {
        if (isMounted) {
          setExplanation(
            `💡 **मूल तथ्य**: ${question.explanationHi}\n\n📚 **विस्तार**: यह प्रश्न ${question.category} के महत्वपूर्ण विषयों से संबंधित है।\n\n🎯 **स्मार्ट ट्रिक**: सही उत्तर '${question.optionsHi[question.correctIndex]}' को मुख्य कीवर्ड से जोड़कर याद रखें।`
          );
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    fetchAiExplanation();
    return () => {
      isMounted = false;
    };
  }, [question, selectedOptionIndex]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl border border-purple-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 px-6 border-b border-purple-100 bg-purple-50/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-purple-900 font-bold">
            <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center shadow-xs">
              <BrainCircuit className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold flex items-center gap-1.5">
                <span>AI गुरु व्याख्या व परीक्षा ट्रिक्स</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              </div>
              <p className="text-[11px] text-purple-700/80 font-normal">
                तथ्य, ऐतिहासिक संदर्भ एवं याद रखने की आसान ट्रिक
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-white/80"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-slate-700">
          {/* Question snapshot */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <span className="font-semibold text-slate-900 block mb-1">
              प्रश्न: {question.questionHi}
            </span>
            <span className="text-emerald-700 font-medium">
              ✓ सही उत्तर: {question.optionsHi[question.correctIndex]}
            </span>
          </div>

          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-500">
              <Loader2 className="w-7 h-7 text-purple-600 animate-spin" />
              <p className="text-xs font-medium">AI गुरु व्याख्या और याद रखने की ट्रिक तैयार कर रहे हैं...</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="whitespace-pre-line leading-relaxed text-slate-800 text-xs sm:text-sm">
                {explanation}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-1 text-[11px] text-slate-500">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            <span>स्मार्ट टिप: रोज 10 नए प्रश्न दोहराएं</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            वापस क्विज़ पर जाएं
          </button>
        </div>
      </div>
    </div>
  );
};
