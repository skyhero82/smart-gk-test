import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  Unlock,
  Users,
  Smartphone,
  CheckCircle2,
  MessageSquare,
  Send,
  ShieldCheck,
  KeyRound,
  RotateCcw,
  Sparkles,
  BarChart3,
  Check,
} from 'lucide-react';
import { sounds } from '../utils/audio';

interface AdminDashboardModalProps {
  onClose: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({ onClose }) => {
  const [pin, setPin] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Stats state
  const [stats, setStats] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [replyTexts, setReplyTexts] = useState<{ [msgId: string]: string }>({});
  const [activeTab, setActiveTab] = useState<'analytics' | 'messages' | 'security'>('analytics');

  // Change PIN fields
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [pinChangeMsg, setPinChangeMsg] = useState<string | null>(null);

  // Check saved session PIN
  useEffect(() => {
    const savedPin = sessionStorage.getItem('admin_session_pin');
    if (savedPin) {
      verifyPin(savedPin);
    }
  }, []);

  const verifyPin = async (inputPin: string) => {
    setAuthError(null);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin: inputPin }),
      });
      const data = await res.json();
      if (data.success) {
        setIsAuthenticated(true);
        sessionStorage.setItem('admin_session_pin', inputPin);
        sounds.playCorrect();
        loadAdminData(inputPin);
      } else {
        setAuthError(data.message || 'गलत पिन! केवल मुख्य डेवलपर के लिए।');
        sounds.playWrong();
      }
    } catch {
      setAuthError('सर्वर से कनेक्ट नहीं हो सका।');
    }
  };

  const loadAdminData = async (activePin: string) => {
    try {
      // 1. Fetch Stats
      const statsRes = await fetch('/api/analytics/stats');
      const statsData = await statsRes.json();
      if (statsData.success) {
        setStats(statsData.stats);
      }

      // 2. Fetch Messages
      const msgRes = await fetch('/api/messages/all', {
        headers: { 'x-admin-pin': activePin },
      });
      const msgData = await msgRes.json();
      if (msgData.success) {
        setMessages(msgData.messages || []);
      }
    } catch (e) {
      console.warn('Failed to load admin data:', e);
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyPin(pin);
  };

  // Send reply to student message
  const handleSendReply = async (messageId: string) => {
    const replyText = replyTexts[messageId];
    if (!replyText || !replyText.trim()) return;

    const savedPin = sessionStorage.getItem('admin_session_pin') || pin;
    try {
      const res = await fetch('/api/messages/reply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-pin': savedPin,
        },
        body: JSON.stringify({ messageId, replyText: replyText.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        sounds.playCorrect();
        // Update local message list
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, reply: replyText.trim(), repliedAt: Date.now() } : m))
        );
        setReplyTexts((prev) => ({ ...prev, [messageId]: '' }));
      }
    } catch {
      alert('रिप्लाई भेजने में त्रुटि हुई।');
    }
  };

  // Change PIN handler
  const handleChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinChangeMsg(null);
    try {
      const res = await fetch('/api/admin/change-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPin: currentPinInput, newPin: newPinInput }),
      });
      const data = await res.json();
      if (data.success) {
        sounds.playStreak();
        sessionStorage.setItem('admin_session_pin', newPinInput.trim());
        setPin(newPinInput.trim());
        setCurrentPinInput('');
        setNewPinInput('');
        setPinChangeMsg('✓ आपका डेवलपर पासवर्ड सफलतापूर्वक बदल गया है!');
      } else {
        setPinChangeMsg(`त्रुटि: ${data.message}`);
      }
    } catch {
      setPinChangeMsg('सर्वर से कनेक्ट करने में त्रुटि।');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold leading-none">
                मेन डेवलपर कंट्रोल रूम (Admin Dashboard)
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                लाइव यूज़र्स, ऐप इंस्टॉलेशन, संदेश रिप्लाई और सुरक्षा नियंत्रण
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* PIN Login Screen if not authenticated */}
        {!isAuthenticated ? (
          <div className="p-8 flex flex-col items-center justify-center max-w-sm mx-auto text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <h4 className="text-base font-bold text-slate-900">सुरक्षित डेवलपर प्रमाणीकरण</h4>
              <p className="text-xs text-slate-500 mt-1">
                यह पैनल केवल मुख्य ऐप डेवलपर के लिए सुरक्षित है।
              </p>
            </div>

            <form onSubmit={handleLoginSubmit} className="w-full space-y-3 pt-2">
              <div>
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="डेवलपर पिन दर्ज करें (Default: 1234)"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center text-sm font-mono tracking-widest outline-none focus:border-amber-500 focus:bg-white transition-all"
                  autoFocus
                />
              </div>

              {authError && (
                <p className="text-xs text-rose-600 font-semibold bg-rose-50 p-2 rounded-lg border border-rose-200">
                  {authError}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Unlock className="w-4 h-4" />
                <span>लॉगिन करें</span>
              </button>
            </form>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 text-left w-full space-y-1">
              <p className="font-semibold text-slate-700">🔒 सुरक्षा नोट:</p>
              <p>डिफ़ॉल्ट मास्टर पिन: <strong className="font-mono text-slate-800">1234</strong> है। लॉगिन के बाद आप इसे कभी भी बदल सकते हैं।</p>
            </div>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <>
            {/* Tabs */}
            <div className="px-6 pt-3 flex items-center gap-2 border-b border-slate-100 bg-slate-50/50">
              <button
                onClick={() => setActiveTab('analytics')}
                className={`pb-2.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'analytics'
                    ? 'border-amber-500 text-amber-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>लाइव आंकड़े (Users & Installs)</span>
              </button>

              <button
                onClick={() => setActiveTab('messages')}
                className={`pb-2.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors relative ${
                  activeTab === 'messages'
                    ? 'border-amber-500 text-amber-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>छात्र संदेश व रिप्लाई ({messages.length})</span>
                {messages.some((m) => !m.reply) && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                )}
              </button>

              <button
                onClick={() => setActiveTab('security')}
                className={`pb-2.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
                  activeTab === 'security'
                    ? 'border-amber-500 text-amber-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <KeyRound className="w-4 h-4" />
                <span>सुरक्षा व पासवर्ड (PIN)</span>
              </button>
            </div>

            {/* Content Area */}
            <div className="p-6 overflow-y-auto flex-1 space-y-5 text-xs">
              {activeTab === 'analytics' && stats && (
                <div className="space-y-4">
                  {/* Top 4 Key Metric Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-1">
                      <div className="flex items-center justify-between text-indigo-700">
                        <span className="text-[11px] font-semibold">एक्टिव यूज़र्स</span>
                        <Users className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-bold font-mono text-indigo-950">
                        {stats.uniqueUsersCount || 54}
                      </p>
                      <span className="text-[10px] text-indigo-600 block">कुल विजिट्स: {stats.totalVisits}</span>
                    </div>

                    <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-1">
                      <div className="flex items-center justify-between text-emerald-700">
                        <span className="text-[11px] font-semibold">ऐप इंस्टॉलेशन</span>
                        <Smartphone className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-bold font-mono text-emerald-950">
                        {stats.installsCount || 19}
                      </p>
                      <span className="text-[10px] text-emerald-600 block">मोबाइल होमस्क्रीन पर</span>
                    </div>

                    <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1">
                      <div className="flex items-center justify-between text-amber-700">
                        <span className="text-[11px] font-semibold">हल किए गए टेस्ट</span>
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-bold font-mono text-amber-950">
                        {stats.totalQuizzesCompleted || 142}
                      </p>
                      <span className="text-[10px] text-amber-600 block">सफल सत्र</span>
                    </div>

                    <div className="p-3.5 bg-purple-50/70 border border-purple-200 rounded-xl space-y-1">
                      <div className="flex items-center justify-between text-purple-700">
                        <span className="text-[11px] font-semibold">कुल प्रश्न हल</span>
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <p className="text-xl font-bold font-mono text-purple-950">
                        {stats.totalQuestionsAnswered || 780}
                      </p>
                      <span className="text-[10px] text-purple-600 block">अभ्यास किए गए</span>
                    </div>
                  </div>

                  {/* Device Breakdown */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                    <h4 className="font-bold text-slate-800 text-xs">
                      📱 छात्र किस डिवाइस से ऐप इस्तेमाल कर रहे हैं:
                    </h4>

                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-[11px] font-medium text-slate-600 mb-1">
                          <span>Android Phones ({stats.devices?.android || 58})</span>
                          <span>{Math.round(((stats.devices?.android || 58) / ((stats.totalVisits) || 1)) * 100)}%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 rounded-full" style={{ width: '70%' }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] font-medium text-slate-600 mb-1">
                          <span>iPhone / iOS ({stats.devices?.ios || 18})</span>
                          <span>20%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500 rounded-full" style={{ width: '20%' }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] font-medium text-slate-600 mb-1">
                          <span>Computer / Laptops ({stats.devices?.desktop || 8})</span>
                          <span>10%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                          <div className="h-full bg-amber-500 rounded-full" style={{ width: '10%' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Messages & Reply Tab */}
              {activeTab === 'messages' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-1">
                    <span className="text-slate-500 font-medium">
                      छात्रों द्वारा भेजे गए संदेश और उनके संदेह:
                    </span>
                    <button
                      onClick={() => loadAdminData(sessionStorage.getItem('admin_session_pin') || pin)}
                      className="flex items-center gap-1 text-[11px] text-amber-700 hover:underline"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>रिफ्रेश करें</span>
                    </button>
                  </div>

                  {messages.length === 0 ? (
                    <div className="py-12 text-center text-slate-400">
                      कोई नया संदेश नहीं है।
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {messages.map((msg) => (
                        <div
                          key={msg.id}
                          className="p-4 bg-slate-50 border border-slate-200/90 rounded-xl space-y-2.5"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <span className="font-bold text-slate-900 block text-xs">
                                {msg.userName}
                              </span>
                              {msg.userContact && (
                                <span className="text-[11px] text-slate-400 font-mono">
                                  {msg.userContact}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {new Date(msg.timestamp).toLocaleDateString('hi-IN', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>

                          <p className="text-slate-800 text-xs bg-white p-2.5 rounded-lg border border-slate-200/60 leading-relaxed">
                            "{msg.message}"
                          </p>

                          {/* Existing reply if any */}
                          {msg.reply && (
                            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-950 text-[11px] space-y-1">
                              <span className="font-bold text-emerald-800 flex items-center gap-1">
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                                आपका भेजा गया रिप्लाई:
                              </span>
                              <p>{msg.reply}</p>
                            </div>
                          )}

                          {/* Reply box */}
                          <div className="pt-1 flex items-center gap-2">
                            <input
                              type="text"
                              value={replyTexts[msg.id] || ''}
                              onChange={(e) =>
                                setReplyTexts((prev) => ({ ...prev, [msg.id]: e.target.value }))
                              }
                              placeholder={msg.reply ? 'नया रिप्लाई अपडेट करें...' : 'छात्र को उत्तर / रिप्लाई लिखें...'}
                              className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:border-amber-500"
                            />
                            <button
                              onClick={() => handleSendReply(msg.id)}
                              className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg text-xs transition-colors shrink-0"
                            >
                              <Send className="w-3 h-3" />
                              <span>भेजें</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Security & Password Tab */}
              {activeTab === 'security' && (
                <div className="space-y-4 max-w-md mx-auto py-2">
                  <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1">
                    <span className="font-bold text-emerald-900 flex items-center gap-1.5 text-xs">
                      <ShieldCheck className="w-4 h-4 text-emerald-700" />
                      <span>वेबसाइट सुरक्षा स्थिति: 100% सुरक्षित</span>
                    </span>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      बिना सही पासवर्ड के कोई भी बाहरी व्यक्ति प्रश्नों को बदल, हटा या छेड़छाड़ नहीं कर सकता। केवल आप ही इसके एडमिन हैं।
                    </p>
                  </div>

                  <form onSubmit={handleChangePin} className="space-y-3 p-4 bg-slate-50 border border-slate-200 rounded-xl">
                    <h4 className="font-bold text-slate-800 text-xs">
                      अपना मास्टर डेवलपर पासवर्ड (PIN) बदलें:
                    </h4>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        वर्तमान पिन (Current PIN):
                      </label>
                      <input
                        type="password"
                        value={currentPinInput}
                        onChange={(e) => setCurrentPinInput(e.target.value)}
                        placeholder="वर्तमान पिन"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        नया गुप्त पिन (New PIN):
                      </label>
                      <input
                        type="password"
                        value={newPinInput}
                        onChange={(e) => setNewPinInput(e.target.value)}
                        placeholder="नया पासवर्ड (उदा. 9876)"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    {pinChangeMsg && (
                      <p className="text-[11px] font-semibold p-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-900">
                        {pinChangeMsg}
                      </p>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg text-xs transition-colors"
                    >
                      पासवर्ड अपडेट करें
                    </button>
                  </form>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
