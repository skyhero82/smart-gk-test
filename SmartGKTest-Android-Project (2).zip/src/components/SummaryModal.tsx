import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { QuizSessionSummary } from '../types/quiz';
import { Award, CheckCircle, XCircle, RotateCcw, Home, Clock, Zap } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SummaryModalProps {
  summary: QuizSessionSummary;
  onRestart: () => void;
  onGoHome: () => void;
}

export const SummaryModal: React.FC<SummaryModalProps> = ({
  summary,
  onRestart,
  onGoHome,
}) => {
  useEffect(() => {
    // Fire celebratory confetti if accuracy is good (>= 60%)
    if (summary.accuracy >= 60) {
      sounds.playStreak();
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#10b981', '#6366f1', '#ec4899'],
        });
      } catch {
        // Ignore
      }
    }
  }, [summary.accuracy]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Banner */}
        <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 text-white p-6 text-center relative overflow-hidden">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center mx-auto mb-3">
            <Award className="w-8 h-8" />
          </div>

          <h2 className="text-xl font-extrabold tracking-tight">
            {summary.accuracy >= 80
              ? 'उत्कृष्ट प्रदर्शन! (Outstanding)'
              : summary.accuracy >= 50
              ? 'अच्छा प्रयास! (Good Job)'
              : 'अभ्यास जारी रखें! (Keep Practicing)'}
          </h2>
          <p className="text-xs text-indigo-200 mt-1">
            {summary.categoryName || 'GK टेस्ट'} पूरा हुआ
          </p>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-2 mt-5 max-w-md mx-auto">
            <div className="bg-white/10 rounded-xl p-2.5 backdrop-blur-xs border border-white/10">
              <span className="block text-[11px] text-indigo-200">सटीकता</span>
              <span className="text-xl font-bold font-mono text-emerald-400">
                {summary.accuracy}%
              </span>
            </div>
            <div className="bg-white/10 rounded-xl p-2.5 backdrop-blur-xs border border-white/10">
              <span className="block text-[11px] text-indigo-200">सही उत्तर</span>
              <span className="text-xl font-bold font-mono text-white">
                {summary.correctCount} / {summary.totalQuestions}
              </span>
            </div>
            <div className="bg-white/10 rounded-xl p-2.5 backdrop-blur-xs border border-white/10">
              <span className="block text-[11px] text-indigo-200">समय लगा</span>
              <span className="text-xl font-bold font-mono text-amber-300">
                {summary.timeSpentSeconds}s
              </span>
            </div>
          </div>
        </div>

        {/* Detailed Question Review */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            प्रश्नों की समीक्षा (Answer Review)
          </h3>

          {summary.questions.map((q, idx) => {
            const userAnswer = summary.userAnswers[q.id];
            const isCorrect = userAnswer === q.correctIndex;
            const isSkipped = userAnswer === undefined || userAnswer === null;

            return (
              <div
                key={q.id}
                className={`p-3.5 rounded-xl border text-xs space-y-1.5 transition-colors ${
                  isCorrect
                    ? 'bg-emerald-50/60 border-emerald-200'
                    : isSkipped
                    ? 'bg-slate-50 border-slate-200'
                    : 'bg-rose-50/60 border-rose-200'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2">
                    <span className="font-bold text-slate-500 min-w-5">
                      {idx + 1}.
                    </span>
                    <span className="font-semibold text-slate-900">
                      {q.questionHi}
                    </span>
                  </div>
                  {isCorrect ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full whitespace-nowrap">
                      <CheckCircle className="w-3 h-3 text-emerald-600" /> सही
                    </span>
                  ) : isSkipped ? (
                    <span className="text-[11px] font-semibold text-slate-500 bg-slate-200/80 px-2 py-0.5 rounded-full whitespace-nowrap">
                      छोड़ा गया
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-100/80 px-2 py-0.5 rounded-full whitespace-nowrap">
                      <XCircle className="w-3 h-3 text-rose-600" /> गलत
                    </span>
                  )}
                </div>

                <div className="pl-7 space-y-1 text-[11px]">
                  <p className="text-slate-600">
                    <strong className="text-slate-700">सही उत्तर:</strong>{' '}
                    <span className="text-emerald-700 font-semibold">{q.optionsHi[q.correctIndex]}</span>
                  </p>
                  {!isCorrect && !isSkipped && (
                    <p className="text-rose-700">
                      <strong>आपका चयन:</strong> {q.optionsHi[userAnswer]}
                    </p>
                  )}
                  <p className="text-slate-500 pt-1 border-t border-slate-200/60">
                    {q.explanationHi}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Actions */}
        <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            onClick={() => {
              sounds.playClick();
              onGoHome();
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 transition-colors"
          >
            <Home className="w-4 h-4" />
            <span>होम स्क्रीन</span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              onRestart();
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>दोबारा टेस्ट दें</span>
          </button>
        </div>
      </div>
    </div>
  );
};
