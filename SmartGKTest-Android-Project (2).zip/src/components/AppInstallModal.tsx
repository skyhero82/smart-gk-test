import React, { useState } from 'react';
import { X, Smartphone, Share2, Copy, Check, Download, ExternalLink } from 'lucide-react';
import { sounds } from '../utils/audio';

interface AppInstallModalProps {
  deferredPrompt: any;
  onInstallNative: () => void;
  onClose: () => void;
}

export const AppInstallModal: React.FC<AppInstallModalProps> = ({
  deferredPrompt,
  onInstallNative,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const appUrl = window.location.href;

  const handleCopyLink = () => {
    sounds.playClick();
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-base shadow-sm">
              GK
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-none">
                Smart GK Test ऐप
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                फोन या कंप्यूटर में ऐप की तरह चलाएं
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If native install prompt available */}
        {deferredPrompt && (
          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
            <p className="text-xs font-semibold text-amber-900">
              ⚡ डायरेक्ट इंस्टॉल उपलब्ध है!
            </p>
            <button
              onClick={() => {
                onInstallNative();
                onClose();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
            >
              <Download className="w-4 h-4" />
              <span>अभी ऐप इंस्टॉल करें (Install App)</span>
            </button>
          </div>
        )}

        {/* Solution 1: Direct Android Chrome WebAPK Install */}
        <div className="p-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="font-extrabold text-emerald-950 text-sm flex items-center gap-1.5">
              <Download className="w-4 h-4 text-emerald-700" />
              <span>अपने Android फ़ोन में सीधे इंस्टॉल करें:</span>
            </span>
            <span className="text-[10px] bg-emerald-600 text-white font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
              100% Free
            </span>
          </div>

          <p className="text-xs text-slate-700 leading-relaxed">
            यह ऐप पूरी तरह से <strong>Android WebAPK सक्षम</strong> है। इसे अपने फ़ोन में ऐप की तरह लाने के लिए नीचे दिया गया बटन दबाएं:
          </p>

          <button
            onClick={() => {
              if (deferredPrompt) {
                onInstallNative();
                onClose();
              } else {
                alert('कृपया अपने मोबाइल Chrome में ऊपर दाईं ओर 3 डॉट्स (⋮) पर टैप करें और "Install app" या "Add to Home screen" चुनें। ऐप आपके फ़ोन की होमस्क्रीन पर आ जाएगा!');
              }
            }}
            className="flex items-center justify-center gap-2 w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-extrabold text-xs sm:text-sm rounded-xl transition-all shadow-md active:scale-[0.98]"
          >
            <Download className="w-4 h-4" />
            <span>यहाँ टैप करके ऐप इंस्टॉल करें (Install App)</span>
          </button>
        </div>

        {/* 2-Step Android Chrome Guide */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 text-xs text-slate-700">
          <span className="font-bold text-slate-900 flex items-center gap-1.5">
            <Smartphone className="w-4 h-4 text-amber-600" />
            <span>Android फ़ोन में इंस्टॉल करने के 2 आसान स्टेप्स:</span>
          </span>

          <div className="space-y-2 text-[11px] text-slate-600 pl-1">
            <div className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-slate-200/80">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-white font-bold flex items-center justify-center shrink-0 text-[11px]">
                1
              </span>
              <p>
                Chrome ब्राउज़र के ऊपर दाईं ओर दिए गए <strong>3 डॉट्स (⋮)</strong> पर क्लिक करें।
              </p>
            </div>

            <div className="flex items-start gap-2 bg-white p-2.5 rounded-xl border border-slate-200/80">
              <span className="w-5 h-5 rounded-full bg-amber-500 text-white font-bold flex items-center justify-center shrink-0 text-[11px]">
                2
              </span>
              <p>
                मेन्यू में <strong>"Install app (ऐप इंस्टॉल करें)"</strong> या <strong>"Add to Home screen (होम स्क्रीन में जोड़ें)"</strong> पर टैप करें।
              </p>
            </div>
          </div>

          <p className="text-[10px] text-emerald-800 font-semibold bg-emerald-50 p-2 rounded-lg border border-emerald-200">
            ✓ यह बिना किसी एरर के सीधा आपके फ़ोन की होमस्क्रीन पर Smart GK का ऐप आइकन बना देगा, जो बिना ब्राउज़र के फुल स्क्रीन में चलेगा!
          </p>
        </div>

        {/* Direct Link Box */}
        <div className="space-y-1.5">
          <label className="block text-xs font-semibold text-slate-700">
            ऐप का डायरेक्ट वेब लिंक:
          </label>
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl p-1.5 pr-2">
            <input
              type="text"
              readOnly
              value={appUrl}
              className="bg-transparent text-xs text-slate-600 px-2 py-1 flex-1 outline-none font-mono truncate"
            />
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shrink-0 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>कॉपी हो गया!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>कॉपी करें</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Instructions */}
        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5 text-xs text-slate-700">
          <span className="font-bold text-slate-900 flex items-center gap-1.5">
            <Smartphone className="w-4 h-4 text-amber-600" />
            <span>मोबाइल में ऐप आइकन कैसे लाएं (Add to Home Screen):</span>
          </span>

          <div className="space-y-2 text-[11px] text-slate-600 pl-1">
            <div className="flex items-start gap-2">
              <span className="font-bold text-amber-600">Android (Chrome):</span>
              <span>
                ऊपर दाईं ओर <strong>3 डॉट्स (⋮)</strong> दबाएं ➔ <strong>"Add to Home screen" (होम स्क्रीन में जोड़ें)</strong> या <strong>"Install app"</strong> चुनें।
              </span>
            </div>
            <div className="flex items-start gap-2">
              <span className="font-bold text-amber-600">iPhone / iPad (Safari):</span>
              <span>
                नीचे <strong>Share (⎋)</strong> आइकन दबाएं ➔ नीचे स्क्रॉल करके <strong>"Add to Home Screen"</strong> चुनें।
              </span>
            </div>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors"
          >
            बंद करें
          </button>
        </div>
      </div>
    </div>
  );
};
