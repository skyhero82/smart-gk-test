import React from 'react';
import { QuizMode } from '../types/quiz';
import { CATEGORIES } from '../data/questionBank';
import { Infinity, Zap, Award, Layers, Sparkles } from 'lucide-react';
import { sounds } from '../utils/audio';

interface ModeSelectorProps {
  currentMode: QuizMode;
  selectedCategory: string;
  onSelectMode: (mode: QuizMode, category?: string) => void;
  onOpenAiGenerator: () => void;
}

export const ModeSelector: React.FC<ModeSelectorProps> = ({
  currentMode,
  selectedCategory,
  onSelectMode,
  onOpenAiGenerator,
}) => {
  return (
    <div className="space-y-3">
      {/* Primary Mode Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-100/90 rounded-xl border border-slate-200">
        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('endless');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all ${
            currentMode === 'endless'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Infinity className="w-3.5 h-3.5 text-amber-500" />
          <span>अनवरत अभ्यास (Endless GK)</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('speed');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all ${
            currentMode === 'speed'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-rose-500" />
          <span>60-सेकंड स्पीड टेस्ट</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('exam');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all ${
            currentMode === 'exam'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-indigo-500" />
          <span>मॉक टेस्ट (10 प्रश्न)</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('category', selectedCategory || 'history');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all ${
            currentMode === 'category'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-emerald-500" />
          <span>विषयवार (Categories)</span>
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onOpenAiGenerator();
          }}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-all text-purple-700 hover:bg-purple-50 ml-auto"
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-600" />
          <span>कस्टम AI टॉपिक</span>
        </button>
      </div>

      {/* Category Pills when in Category Mode */}
      {currentMode === 'category' && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 no-scrollbar text-xs">
          <span className="text-slate-400 font-medium text-[11px] whitespace-nowrap">विषय चुनें:</span>
          {CATEGORIES.filter(c => c.id !== 'all').map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                sounds.playClick();
                onSelectMode('category', cat.nameHi);
              }}
              className={`px-2.5 py-1 rounded-md transition-colors whitespace-nowrap text-xs font-medium border ${
                selectedCategory === cat.nameHi
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
              }`}
            >
              {cat.nameHi}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
