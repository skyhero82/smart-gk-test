import React, { useState } from 'react';
import { Sparkles, X, Loader2, ArrowRight } from 'lucide-react';
import { Difficulty, Question } from '../types/quiz';

interface AiQuizModalProps {
  onQuestionsGenerated: (questions: Question[], topic: string) => void;
  onClose: () => void;
}

const QUICK_TOPICS = [
  'चंद्रयान 3 व इसरो अंतरिक्ष मिशन',
  'भारतीय स्वतंत्रता संग्राम (1857-1947)',
  'भारत की प्रमुख नदियाँ, पर्वत और बांध',
  'मानव शरीर एवं प्रमुख रोग व विटामिन',
  'विश्व के प्रमुख देश, राजधानियाँ व मुद्रा',
  'कंप्यूटर एवं आधुनिक इंटरनेट प्रौद्योगिकी',
  'भारतीय संविधान के प्रमुख अनुच्छेद व संशोधन',
  'ओलंपिक एवं क्रिकेट विश्व कप इतिहास',
];

export const AiQuizModal: React.FC<AiQuizModalProps> = ({
  onQuestionsGenerated,
  onClose,
}) => {
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [count, setCount] = useState<number>(5);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!topic.trim()) {
      setErrorMsg('कृपया कोई टॉपिक लिखें या नीचे दिए गए सुझावों में से चुनें।');
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          difficulty,
          count,
          language: 'bilingual',
        }),
      });

      const data = await res.json();

      if (data.success && Array.isArray(data.questions) && data.questions.length > 0) {
        onQuestionsGenerated(data.questions, topic.trim());
      } else {
        setErrorMsg('AI प्रश्न जनरेट नहीं हो सके। कृपया दोबारा प्रयास करें या अंतर्निहित प्रश्नों से अभ्यास करें।');
      }
    } catch (err: any) {
      setErrorMsg('कनेक्शन त्रुटि। कृपया दोबारा प्रयास करें।');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                AI स्मार्ट GK प्रश्न जनरेटर
              </h2>
              <p className="text-xs text-slate-500">
                अपनी पसंद के किसी भी विषय पर तुरंत नए क्विज़ प्रश्न बनाएं
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="space-y-4 py-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              आप किस टॉपिक पर GK टेस्ट देना चाहते हैं?
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="उदा. भारतीय अंतरिक्ष मिशन, मुगल साम्राज्य, संविधान..."
              className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600 focus:bg-white transition-all text-slate-900 placeholder:text-slate-400"
            />
          </div>

          {/* Quick topic suggestion tags */}
          <div>
            <span className="text-[11px] font-medium text-slate-400 block mb-1.5">
              लोकप्रिय सुझाव (क्लिक करें):
            </span>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
              {QUICK_TOPICS.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setTopic(item)}
                  className="px-2.5 py-1 text-[11px] bg-slate-100 hover:bg-purple-50 hover:text-purple-700 hover:border-purple-200 text-slate-700 rounded-lg border border-slate-200/80 transition-colors text-left"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty & Count */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                कठिनाई स्तर:
              </label>
              <div className="flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 text-xs">
                {(['easy', 'medium', 'hard'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setDifficulty(lvl)}
                    className={`flex-1 py-1.5 font-medium rounded-md transition-colors ${
                      difficulty === lvl
                        ? 'bg-white text-purple-700 font-bold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {lvl === 'easy' ? 'सरल' : lvl === 'medium' ? 'मध्यम' : 'कठिन'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                प्रश्नों की संख्या:
              </label>
              <div className="flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 text-xs">
                {[5, 10].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setCount(num)}
                    className={`flex-1 py-1.5 font-medium rounded-md transition-colors ${
                      count === num
                        ? 'bg-white text-purple-700 font-bold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {num} प्रश्न
                  </button>
                ))}
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-medium">
              {errorMsg}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
          >
            रद्द करें
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={handleGenerate}
            className="flex items-center gap-1.5 px-4 py-2 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>AI प्रश्न तैयार कर रहा है...</span>
              </>
            ) : (
              <>
                <span>क्विज़ शुरू करें</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
