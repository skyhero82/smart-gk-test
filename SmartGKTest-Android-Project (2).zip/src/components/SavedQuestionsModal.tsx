import React, { useState } from 'react';
import { Bookmark, AlertCircle, X, Trash2, Play, CheckCircle2 } from 'lucide-react';
import { Question } from '../types/quiz';
import { sounds } from '../utils/audio';

interface SavedQuestionsModalProps {
  initialTab: 'bookmarks' | 'mistakes';
  bookmarkedQuestions: Question[];
  mistakeQuestions: Question[];
  onRemoveBookmark: (id: string) => void;
  onRemoveMistake: (id: string) => void;
  onStartPractice: (questions: Question[], title: string) => void;
  onClose: () => void;
}

export const SavedQuestionsModal: React.FC<SavedQuestionsModalProps> = ({
  initialTab,
  bookmarkedQuestions,
  mistakeQuestions,
  onRemoveBookmark,
  onRemoveMistake,
  onStartPractice,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'bookmarks' | 'mistakes'>(initialTab);

  const currentList = activeTab === 'bookmarks' ? bookmarkedQuestions : mistakeQuestions;
  const title = activeTab === 'bookmarks' ? 'बुकमार्क प्रश्न (Saved)' : 'गलतियों की समीक्षा (Mistakes Bank)';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Header Tabs */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => {
                sounds.playClick();
                setActiveTab('bookmarks');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'bookmarks'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-amber-500" />
              <span>सहेजे गए प्रश्न ({bookmarkedQuestions.length})</span>
            </button>

            <button
              onClick={() => {
                sounds.playClick();
                setActiveTab('mistakes');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'mistakes'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
              <span>गलतियों का बैंक ({mistakeQuestions.length})</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          {currentList.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <p className="text-sm font-medium">
                {activeTab === 'bookmarks'
                  ? 'आपने अभी तक कोई प्रश्न बुकमार्क नहीं किया है।'
                  : 'शानदार! गलतियों के बैंक में कोई प्रश्न नहीं है।'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                क्विज़ हल करते समय बुकमार्क आइकन दबाकर प्रश्न सहेज सकते हैं।
              </p>
            </div>
          ) : (
            currentList.map((q, idx) => (
              <div
                key={q.id}
                className="p-4 bg-slate-50 hover:bg-slate-50/80 rounded-xl border border-slate-200/80 transition-colors space-y-2 text-xs"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {q.category} · प्रश्न {idx + 1}
                    </span>
                    <p className="font-semibold text-slate-900 text-sm">
                      {q.questionHi}
                    </p>
                    <p className="text-slate-500 text-xs">
                      {q.questionEn}
                    </p>
                  </div>

                  <button
                    onClick={() => {
                      sounds.playClick();
                      if (activeTab === 'bookmarks') onRemoveBookmark(q.id);
                      else onRemoveMistake(q.id);
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="सूची से हटाएं"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    सही उत्तर: {q.optionsHi[q.correctIndex]}
                  </span>
                  <span className="text-slate-400">
                    कठिनाई: {q.difficulty === 'easy' ? 'सरल' : q.difficulty === 'medium' ? 'मध्यम' : 'कठिन'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {currentList.length > 0 && (
          <div className="p-4 px-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">
              कुल {currentList.length} प्रश्न उपलब्ध
            </span>
            <button
              onClick={() => {
                sounds.playClick();
                onStartPractice(currentList, title);
                onClose();
              }}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>इनका टेस्ट शुरू करें</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
