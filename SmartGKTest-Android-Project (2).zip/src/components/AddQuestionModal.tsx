import React, { useState } from 'react';
import { X, PlusCircle, CheckCircle2, Download, Upload, Trash2, BookPlus } from 'lucide-react';
import { Difficulty, Question } from '../types/quiz';
import { sounds } from '../utils/audio';

interface AddQuestionModalProps {
  customQuestions: Question[];
  onAddQuestion: (q: Question) => void;
  onDeleteQuestion: (id: string) => void;
  onImportQuestions: (questions: Question[]) => void;
  onClose: () => void;
}

export const AddQuestionModal: React.FC<AddQuestionModalProps> = ({
  customQuestions,
  onAddQuestion,
  onDeleteQuestion,
  onImportQuestions,
  onClose,
}) => {
  const [tab, setTab] = useState<'create' | 'manage'>('create');

  // Form fields
  const [category, setCategory] = useState('मेरी कोचिंग / अध्ययन नोट्स');
  const [questionHi, setQuestionHi] = useState('');
  const [questionEn, setQuestionEn] = useState('');
  const [opt0, setOpt0] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [correctIndex, setCorrectIndex] = useState<number>(0);
  const [explanationHi, setExplanationHi] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [tag, setTag] = useState('स्व-अध्ययन');

  const [message, setMessage] = useState<string | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionHi.trim()) {
      setMessage('कृपया प्रश्न दर्ज करें।');
      return;
    }
    if (!opt0.trim() || !opt1.trim() || !opt2.trim() || !opt3.trim()) {
      setMessage('कृपया चारों विकल्प (A, B, C, D) भरें।');
      return;
    }

    const newQ: Question = {
      id: `custom-${Date.now()}`,
      category: category.trim() || 'कस्टम अध्ययन',
      questionHi: questionHi.trim(),
      questionEn: questionEn.trim() || questionHi.trim(),
      optionsHi: [opt0.trim(), opt1.trim(), opt2.trim(), opt3.trim()],
      optionsEn: [
        opt0.trim(),
        opt1.trim(),
        opt2.trim(),
        opt3.trim(),
      ],
      correctIndex,
      explanationHi: explanationHi.trim() || 'सही उत्तर: ' + [opt0, opt1, opt2, opt3][correctIndex],
      explanationEn: explanationHi.trim() || 'Correct answer: ' + [opt0, opt1, opt2, opt3][correctIndex],
      difficulty,
      tag: tag.trim() || 'कस्टम नोट्स',
    };

    sounds.playCorrect();
    onAddQuestion(newQ);

    // Reset fields
    setQuestionHi('');
    setQuestionEn('');
    setOpt0('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setExplanationHi('');
    setMessage('✓ नया प्रश्न सफलतापूर्वक आपके क्विज़ बैंक में जुड़ गया!');
    setTimeout(() => setMessage(null), 3500);
  };

  // Export questions to JSON
  const handleExport = () => {
    sounds.playClick();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(customQuestions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `smart_gk_my_questions_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import questions from JSON
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], 'UTF-8');
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (Array.isArray(parsed)) {
            onImportQuestions(parsed);
            sounds.playStreak();
            setMessage(`✓ ${parsed.length} प्रश्न सफलतापूर्वक लोड कर लिए गए!`);
            setTimeout(() => setMessage(null), 3500);
          }
        } catch {
          setMessage('फ़ाइल पढ़ने में त्रुटि। कृपया मान्य JSON फ़ाइल चुनें।');
        }
      };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <BookPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-none">
                अध्ययन नोट्स से अपने प्रश्न जोड़ें
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                अपनी पढ़ाई, कोचिंग या सिलेबस के अनुसार क्विज़ कस्टमाइज़ करें
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-6 pt-3 flex items-center gap-2 border-b border-slate-100">
          <button
            onClick={() => setTab('create')}
            className={`pb-2 text-xs font-semibold border-b-2 transition-colors ${
              tab === 'create'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            + नया प्रश्न जोड़ें
          </button>
          <button
            onClick={() => setTab('manage')}
            className={`pb-2 text-xs font-semibold border-b-2 transition-colors ${
              tab === 'manage'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            मेरे सहेजे गए प्रश्न ({customQuestions.length})
          </button>
        </div>

        {/* Message Banner */}
        {message && (
          <div className="mx-6 mt-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 font-medium">
            {message}
          </div>
        )}

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 text-xs">
          {tab === 'create' ? (
            <form onSubmit={handleSave} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    विषय / कैटेगरी (Subject/Topic):
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="उदा. भारतीय भूगोल, कोचिंग टेस्ट-1"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    टैग (Tag):
                  </label>
                  <input
                    type="text"
                    value={tag}
                    onChange={(e) => setTag(e.target.value)}
                    placeholder="उदा. चैप्टर 4, रिविजन"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  प्रश्न (Question in Hindi)*:
                </label>
                <textarea
                  rows={2}
                  value={questionHi}
                  onChange={(e) => setQuestionHi(e.target.value)}
                  placeholder="अपना GK प्रश्न यहाँ लिखें..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-500 mb-1">
                  अंग्रेजी में प्रश्न (वैकल्पिक):
                </label>
                <input
                  type="text"
                  value={questionEn}
                  onChange={(e) => setQuestionEn(e.target.value)}
                  placeholder="Question in English (optional)"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                />
              </div>

              {/* 4 Options with radio for correct answer */}
              <div className="space-y-2 pt-1">
                <span className="block font-semibold text-slate-700">
                  4 विकल्प दर्ज करें और सही विकल्प के सामने टिक करें*:
                </span>

                {[
                  { label: 'A', val: opt0, setVal: setOpt0, idx: 0 },
                  { label: 'B', val: opt1, setVal: setOpt1, idx: 1 },
                  { label: 'C', val: opt2, setVal: setOpt2, idx: 2 },
                  { label: 'D', val: opt3, setVal: setOpt3, idx: 3 },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-2">
                    <label className="flex items-center gap-1.5 cursor-pointer shrink-0">
                      <input
                        type="radio"
                        name="correctAnswerRadio"
                        checked={correctIndex === item.idx}
                        onChange={() => setCorrectIndex(item.idx)}
                        className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="w-5 h-5 rounded-md bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-[11px]">
                        {item.label}
                      </span>
                    </label>
                    <input
                      type="text"
                      value={item.val}
                      onChange={(e) => item.setVal(e.target.value)}
                      placeholder={`विकल्प ${item.label}`}
                      className={`flex-1 px-3 py-1.5 rounded-lg border text-xs outline-none ${
                        correctIndex === item.idx
                          ? 'border-emerald-500 bg-emerald-50/40 text-emerald-950 font-medium'
                          : 'border-slate-200 bg-slate-50'
                      }`}
                      required
                    />
                    {correctIndex === item.idx && (
                      <span className="text-[10px] font-bold text-emerald-700 shrink-0">
                        (सही उत्तर)
                      </span>
                    )}
                  </div>
                ))}
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  विस्तृत व्याख्या / ट्रिक (Explanation/Trick):
                </label>
                <textarea
                  rows={2}
                  value={explanationHi}
                  onChange={(e) => setExplanationHi(e.target.value)}
                  placeholder="यह उत्तर सही क्यों है या इसे याद रखने की ट्रिक..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition-colors"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>यह प्रश्न क्विज़ में जोड़ें</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              {/* Actions bar for import/export */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExport}
                    disabled={customQuestions.length === 0}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-40 rounded-lg font-medium text-slate-700"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>प्रश्नों को डाउनलोड (Backup) करें</span>
                  </button>

                  <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg font-medium text-slate-700 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>फ़ाइल से लोड (Restore) करें</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {customQuestions.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-1">
                  <p className="font-medium text-slate-500">अभी कोई कस्टम प्रश्न नहीं जोड़ा गया है।</p>
                  <p className="text-[11px]">ऊपर '+ नया प्रश्न जोड़ें' टैब से अपने अध्ययन के प्रश्न जोड़ें।</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {customQuestions.map((q, idx) => (
                    <div
                      key={q.id}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-start justify-between gap-2"
                    >
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                          {q.category} · प्रश्न {idx + 1}
                        </span>
                        <p className="font-semibold text-slate-900 text-xs">
                          {q.questionHi}
                        </p>
                        <p className="text-emerald-700 text-[11px] font-medium">
                          ✓ सही उत्तर: {q.optionsHi[q.correctIndex]}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          sounds.playClick();
                          onDeleteQuestion(q.id);
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="हटाएं"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
