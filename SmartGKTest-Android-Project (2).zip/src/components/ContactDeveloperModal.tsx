import React, { useState, useEffect } from 'react';
import { X, Send, MessageSquare, Check, HelpCircle, User, Phone, CheckCircle2 } from 'lucide-react';
import { sounds } from '../utils/audio';

interface ContactDeveloperModalProps {
  onClose: () => void;
}

export const ContactDeveloperModal: React.FC<ContactDeveloperModalProps> = ({ onClose }) => {
  const [userName, setUserName] = useState('');
  const [userContact, setUserContact] = useState('');
  const [message, setMessage] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);
  const [myMessages, setMyMessages] = useState<any[]>([]);

  // Unique local user id
  const getUserId = () => {
    let id = localStorage.getItem('smart_gk_client_uuid');
    if (!id) {
      id = `usr-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      localStorage.setItem('smart_gk_client_uuid', id);
    }
    return id;
  };

  useEffect(() => {
    fetchMyMessages();
  }, []);

  const fetchMyMessages = async () => {
    const userId = getUserId();
    try {
      const res = await fetch(`/api/messages/user/${userId}`);
      const data = await res.json();
      if (data.success) {
        setMyMessages(data.messages || []);
      }
    } catch {}
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const userId = getUserId();
    try {
      const res = await fetch('/api/messages/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          userName: userName.trim() || 'प्रतियोगी छात्र',
          userContact: userContact.trim(),
          message: message.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        sounds.playCorrect();
        setSentSuccess(true);
        setMessage('');
        fetchMyMessages();
        setTimeout(() => setSentSuccess(false), 4000);
      }
    } catch {
      alert('संदेश भेजने में त्रुटि हुई।');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 px-6 border-b border-slate-100 flex items-center justify-between bg-amber-500 text-white">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 text-white flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold leading-none">
                डेवलपर से पूछें (Help & Feedback)
              </h3>
              <p className="text-[11px] text-amber-100 mt-1">
                कोई प्रश्न में संदेह हो या नई मांग हो, तो सीधा मैसेज भेजें
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          {sentSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>आपका संदेश डेवलपर तक पहुँच गया है! डेवलपर जल्द ही उत्तर देंगे।</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSend} className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <h4 className="font-bold text-slate-800 text-xs">
              नया संदेश / संदेह भेजें:
            </h4>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  आपका नाम:
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="उदा. अमित शर्मा"
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  मोबाइल / ईमेल (वैकल्पिक):
                </label>
                <input
                  type="text"
                  value={userContact}
                  onChange={(e) => setUserContact(e.target.value)}
                  placeholder="संपर्क नंबर"
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                आपका संदेश / प्रश्न संदेह*:
              </label>
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="सर, मुझे इस प्रश्न में शंका है... / कृपया इस विषय पर भी क्विज़ जोड़ें..."
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg text-xs transition-colors shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>संदेश भेजें</span>
              </button>
            </div>
          </form>

          {/* Previous Messages & Replies */}
          {myMessages.length > 0 && (
            <div className="space-y-2 pt-2">
              <h4 className="font-bold text-slate-800 text-xs">
                आपके भेजे गए संदेश और डेवलपर के उत्तर:
              </h4>

              <div className="space-y-2">
                {myMessages.map((msg) => (
                  <div key={msg.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                    <div className="flex justify-between text-[10px] text-slate-400">
                      <span>आपने पूछा:</span>
                      <span>{new Date(msg.timestamp).toLocaleDateString('hi-IN')}</span>
                    </div>
                    <p className="text-slate-800 font-medium">"{msg.message}"</p>

                    {msg.reply ? (
                      <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-950 text-[11px] space-y-0.5">
                        <span className="font-bold text-emerald-800 flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-600" /> डेवलपर का उत्तर (Reply):
                        </span>
                        <p>{msg.reply}</p>
                      </div>
                    ) : (
                      <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-medium inline-block mt-1">
                        ⏳ डेवलपर समीक्षा कर रहे हैं...
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
