import React from 'react';
import { Infinity, Zap, Award, BookPlus, ShieldCheck } from 'lucide-react';
import { QuizMode } from '../types/quiz';
import { sounds } from '../utils/audio';

interface MobileBottomNavProps {
  currentMode: QuizMode;
  onSelectMode: (mode: QuizMode) => void;
  onOpenAddQuestionModal: () => void;
  onOpenAdminDashboard: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentMode,
  onSelectMode,
  onOpenAddQuestionModal,
  onOpenAdminDashboard,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-[430px] mx-auto bg-white/95 backdrop-blur-md border-t border-slate-200 z-40 select-none shadow-lg">
      <div className="grid grid-cols-5 py-1.5 px-1 text-center">
        {/* Endless Quiz Tab */}
        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('endless');
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentMode === 'endless'
              ? 'text-amber-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <div className={`p-1 rounded-lg ${currentMode === 'endless' ? 'bg-amber-50' : ''}`}>
            <Infinity className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 leading-tight">क्विज़</span>
        </button>

        {/* Speed Test Tab */}
        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('speed');
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentMode === 'speed'
              ? 'text-rose-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <div className={`p-1 rounded-lg ${currentMode === 'speed' ? 'bg-rose-50' : ''}`}>
            <Zap className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 leading-tight">स्पीड</span>
        </button>

        {/* Exam Test Tab */}
        <button
          onClick={() => {
            sounds.playClick();
            onSelectMode('exam');
          }}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            currentMode === 'exam'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-400 hover:text-slate-700'
          }`}
        >
          <div className={`p-1 rounded-lg ${currentMode === 'exam' ? 'bg-indigo-50' : ''}`}>
            <Award className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 leading-tight">मॉक टेस्ट</span>
        </button>

        {/* Add Question / Notes Tab */}
        <button
          onClick={() => {
            sounds.playClick();
            onOpenAddQuestionModal();
          }}
          className="flex flex-col items-center justify-center py-1 rounded-xl transition-all text-emerald-600 hover:text-emerald-700"
        >
          <div className="p-1 rounded-lg bg-emerald-50">
            <BookPlus className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 font-bold leading-tight">+ नोट्स</span>
        </button>

        {/* Admin Dashboard Tab */}
        <button
          onClick={() => {
            sounds.playClick();
            onOpenAdminDashboard();
          }}
          className="flex flex-col items-center justify-center py-1 rounded-xl transition-all text-slate-500 hover:text-slate-800"
        >
          <div className="p-1 rounded-lg">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-[10px] mt-0.5 leading-tight font-medium">एडमिन</span>
        </button>
      </div>
    </nav>
  );
};
