import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { MobileTopBar } from './components/MobileTopBar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { QuizCard } from './components/QuizCard';
import { AudiencePollModal } from './components/AudiencePollModal';
import { AiGuruModal } from './components/AiGuruModal';
import { AiQuizModal } from './components/AiQuizModal';
import { SummaryModal } from './components/SummaryModal';
import { SavedQuestionsModal } from './components/SavedQuestionsModal';
import { AppInstallModal } from './components/AppInstallModal';
import { AddQuestionModal } from './components/AddQuestionModal';
import { PlayStoreGuideModal } from './components/PlayStoreGuideModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { ContactDeveloperModal } from './components/ContactDeveloperModal';
import { DEFAULT_QUESTIONS, CATEGORIES } from './data/questionBank';
import { LanguageMode, Question, QuizMode, QuizSessionSummary, UserStats } from './types/quiz';
import { sounds } from './utils/audio';
import { Timer, Zap, Trophy, Sparkles, BookOpen, RotateCcw, Download } from 'lucide-react';

// Fisher-Yates shuffle
function shuffleArray<T>(arr: T[]): T[] {
  const copied = [...arr];
  for (let i = copied.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copied[i], copied[j]] = [copied[j], copied[i]];
  }
  return copied;
}

export default function App() {
  // --- Persistent User Stats ---
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('smart_gk_user_stats');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return {
      totalAnswered: 0,
      correctAnswers: 0,
      currentStreak: 0,
      maxStreak: 0,
      coins: 0,
      bookmarks: [],
      mistakes: [],
    };
  });

  useEffect(() => {
    localStorage.setItem('smart_gk_user_stats', JSON.stringify(stats));
  }, [stats]);

  // --- Persistent Preferences ---
  const [languageMode, setLanguageMode] = useState<LanguageMode>(() => {
    return (localStorage.getItem('smart_gk_lang') as LanguageMode) || 'hi';
  });

  const handleLanguageChange = (lang: LanguageMode) => {
    setLanguageMode(lang);
    localStorage.setItem('smart_gk_lang', lang);
  };

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => sounds.isEnabled());
  const handleToggleSound = () => {
    const newVal = sounds.toggleSound();
    setSoundEnabled(newVal);
  };

  const [autoAdvanceEnabled, setAutoAdvanceEnabled] = useState<boolean>(() => {
    return localStorage.getItem('smart_gk_auto_advance') === 'true';
  });

  const handleToggleAutoAdvance = () => {
    const newVal = !autoAdvanceEnabled;
    setAutoAdvanceEnabled(newVal);
    localStorage.setItem('smart_gk_auto_advance', String(newVal));
  };

  // --- Custom Questions from User Study/Curriculum ---
  const [customQuestions, setCustomQuestions] = useState<Question[]>(() => {
    const saved = localStorage.getItem('smart_gk_custom_questions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('smart_gk_custom_questions', JSON.stringify(customQuestions));
  }, [customQuestions]);

  // All questions pool (Default + Custom)
  const allAvailableQuestions = useMemo(() => {
    return [...customQuestions, ...DEFAULT_QUESTIONS];
  }, [customQuestions]);

  // --- Quiz Mode & Session State ---
  const [currentMode, setCurrentMode] = useState<QuizMode>('endless');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeQuestions, setActiveQuestions] = useState<Question[]>(() => shuffleArray([...customQuestions, ...DEFAULT_QUESTIONS]));
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [sessionAnswers, setSessionAnswers] = useState<{ [qId: string]: number }>({});
  const [sessionStartTime, setSessionStartTime] = useState<number>(Date.now());
  const [customTopicTitle, setCustomTopicTitle] = useState<string | null>(null);

  // Speed mode timer (60s)
  const [speedTimer, setSpeedTimer] = useState<number>(60);
  const [isSpeedRunning, setIsSpeedRunning] = useState<boolean>(false);

  // Modals
  const [showAudiencePoll, setShowAudiencePoll] = useState<boolean>(false);
  const [showAiGuru, setShowAiGuru] = useState<boolean>(false);
  const [showAiModal, setShowAiModal] = useState<boolean>(false);
  const [showInstallModal, setShowInstallModal] = useState<boolean>(false);
  const [showAddQuestionModal, setShowAddQuestionModal] = useState<boolean>(false);
  const [showPlayStoreGuide, setShowPlayStoreGuide] = useState<boolean>(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState<boolean>(false);
  const [showContactModal, setShowContactModal] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [savedModalTab, setSavedModalTab] = useState<'bookmarks' | 'mistakes' | null>(null);
  const [summaryData, setSummaryData] = useState<QuizSessionSummary | null>(null);

  // Track visit analytics on mount
  useEffect(() => {
    let visitorId = localStorage.getItem('smart_gk_client_uuid');
    if (!visitorId) {
      visitorId = `v-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
      localStorage.setItem('smart_gk_client_uuid', visitorId);
    }
    fetch('/api/analytics/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'visit',
        visitorId,
        device: navigator.userAgent || 'Android',
      }),
    }).catch(() => {});
  }, []);

  // Catch PWA install prompt
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallNative = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then(() => {
        setDeferredPrompt(null);
        // Track install
        fetch('/api/analytics/track', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'install' }),
        }).catch(() => {});
      });
    }
  };

  // Helper to load questions based on mode
  const setupQuestionsForMode = useCallback(
    (mode: QuizMode, category: string = 'all', customQs?: Question[]) => {
      const pool = [...customQuestions, ...DEFAULT_QUESTIONS];
      let qs: Question[] = [];
      if (customQs && customQs.length > 0) {
        qs = customQs;
      } else if (mode === 'category' && category && category !== 'all') {
        qs = pool.filter((q) => q.category.includes(category) || category.includes(q.category));
        if (qs.length === 0) qs = pool;
      } else if (mode === 'exam') {
        qs = shuffleArray(pool).slice(0, 10);
      } else {
        qs = shuffleArray(pool);
      }

      setActiveQuestions(qs);
      setCurrentIndex(0);
      setSessionAnswers({});
      setSessionStartTime(Date.now());

      if (mode === 'speed') {
        setSpeedTimer(60);
        setIsSpeedRunning(true);
      } else {
        setIsSpeedRunning(false);
      }
    },
    [customQuestions]
  );

  // Mode Selection Handler
  const handleSelectMode = (mode: QuizMode, category?: string) => {
    setCurrentMode(mode);
    if (category) setSelectedCategory(category);
    setCustomTopicTitle(null);
    setupQuestionsForMode(mode, category || selectedCategory);
  };

  // Speed Timer countdown effect
  useEffect(() => {
    if (currentMode !== 'speed' || !isSpeedRunning || speedTimer <= 0) return;

    const interval = setInterval(() => {
      setSpeedTimer((prev) => {
        if (prev <= 1) {
          setIsSpeedRunning(false);
          // Finish speed test & trigger summary
          handleFinishSession();
          return 0;
        }
        if (prev <= 6) {
          sounds.playTick();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentMode, isSpeedRunning, speedTimer]);

  // Current active question
  const currentQuestion = activeQuestions[currentIndex] || activeQuestions[0];

  // Answer selected handler
  const handleAnswerSelected = (selectedIndex: number, isCorrect: boolean) => {
    setSessionAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: selectedIndex,
    }));

    setStats((prev) => {
      const newStreak = isCorrect ? prev.currentStreak + 1 : 0;
      const newMaxStreak = Math.max(newStreak, prev.maxStreak);
      const earnedCoins = isCorrect ? 10 + newStreak * 2 : 0;

      // Handle mistakes bank
      let newMistakes = [...prev.mistakes];
      if (!isCorrect && !newMistakes.includes(currentQuestion.id)) {
        newMistakes.push(currentQuestion.id);
      } else if (isCorrect && newMistakes.includes(currentQuestion.id)) {
        // Mastered! Can remove from mistakes
        newMistakes = newMistakes.filter((id) => id !== currentQuestion.id);
      }

      return {
        ...prev,
        totalAnswered: prev.totalAnswered + 1,
        correctAnswers: isCorrect ? prev.correctAnswers + 1 : prev.correctAnswers,
        currentStreak: newStreak,
        maxStreak: newMaxStreak,
        coins: prev.coins + earnedCoins,
        mistakes: newMistakes,
      };
    });

    if (isCorrect && stats.currentStreak + 1 >= 5 && (stats.currentStreak + 1) % 5 === 0) {
      sounds.playStreak();
    }
  };

  // Next question handler (Endless loop or finish if exam/speed)
  const handleNextQuestion = () => {
    // If exam mode and last question, show summary
    if (currentMode === 'exam' && currentIndex >= activeQuestions.length - 1) {
      handleFinishSession();
      return;
    }

    if (currentIndex >= activeQuestions.length - 1) {
      // In Endless mode, seamlessly reshuffle so questions keep flowing!
      setActiveQuestions(shuffleArray(allAvailableQuestions));
      setCurrentIndex(0);
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  // Custom Questions operations
  const handleAddCustomQuestion = (q: Question) => {
    setCustomQuestions((prev) => [q, ...prev]);
    setActiveQuestions((prev) => [q, ...prev]);
  };

  const handleDeleteCustomQuestion = (id: string) => {
    setCustomQuestions((prev) => prev.filter((q) => q.id !== id));
    setActiveQuestions((prev) => prev.filter((q) => q.id !== id));
  };

  const handleImportCustomQuestions = (newQs: Question[]) => {
    setCustomQuestions((prev) => [...newQs, ...prev]);
    setActiveQuestions((prev) => shuffleArray([...newQs, ...prev, ...DEFAULT_QUESTIONS]));
  };

  // Skip question
  const handleSkipQuestion = () => {
    handleNextQuestion();
  };

  // Finish session & compute summary
  const handleFinishSession = () => {
    const answeredCount = Object.keys(sessionAnswers).length;
    let correct = 0;
    activeQuestions.forEach((q) => {
      if (sessionAnswers[q.id] === q.correctIndex) {
        correct += 1;
      }
    });

    const total = activeQuestions.length;
    const wrong = answeredCount - correct;
    const skipped = total - answeredCount;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    const timeSpent = Math.max(1, Math.round((Date.now() - sessionStartTime) / 1000));

    setSummaryData({
      mode: currentMode,
      categoryName: customTopicTitle || (currentMode === 'category' ? selectedCategory : 'GK टेस्ट'),
      totalQuestions: total,
      correctCount: correct,
      wrongCount: wrong,
      skippedCount: skipped,
      score: correct * 10,
      accuracy,
      timeSpentSeconds: timeSpent,
      questions: activeQuestions,
      userAnswers: sessionAnswers,
    });
  };

  // Toggle bookmark for question
  const handleToggleBookmark = (id: string) => {
    setStats((prev) => {
      const exists = prev.bookmarks.includes(id);
      return {
        ...prev,
        bookmarks: exists ? prev.bookmarks.filter((bId) => bId !== id) : [...prev.bookmarks, id],
      };
    });
  };

  // AI Quiz generated handler
  const handleAiQuestionsGenerated = (questions: Question[], topic: string) => {
    setShowAiModal(false);
    setCurrentMode('ai-custom');
    setCustomTopicTitle(topic);
    setupQuestionsForMode('ai-custom', topic, questions);
  };

  // Start practice from bookmarks or mistakes
  const handleStartPracticeFromList = (questions: Question[], title: string) => {
    setCurrentMode('category');
    setCustomTopicTitle(title);
    setupQuestionsForMode('category', title, questions);
  };

  // Resolved list of bookmarked questions
  const bookmarkedQuestions = useMemo(() => {
    return allAvailableQuestions.filter((q) => stats.bookmarks.includes(q.id));
  }, [allAvailableQuestions, stats.bookmarks]);

  // Resolved list of mistake questions
  const mistakeQuestions = useMemo(() => {
    return allAvailableQuestions.filter((q) => stats.mistakes.includes(q.id));
  }, [allAvailableQuestions, stats.mistakes]);

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-start sm:py-4 select-none">
      {/* Native Mobile Android Container */}
      <div className="w-full max-w-[430px] min-h-screen sm:min-h-[844px] sm:max-h-[92vh] sm:rounded-[40px] bg-slate-50 flex flex-col shadow-2xl relative overflow-hidden sm:border-[6px] sm:border-slate-800">
        
        {/* Android Phone Speaker / Notch Indicator (visible on laptop/desktop mockup) */}
        <div className="hidden sm:flex items-center justify-center pt-2 pb-1 bg-amber-500 shrink-0">
          <div className="w-16 h-1.5 bg-amber-600/60 rounded-full" />
        </div>

        {/* Mobile Android Top App Bar */}
        <MobileTopBar
          stats={stats}
          languageMode={languageMode}
          onLanguageChange={handleLanguageChange}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          onOpenSavedModal={(tab) => setSavedModalTab(tab)}
          onOpenInstallModal={() => setShowInstallModal(true)}
          onOpenContactModal={() => setShowContactModal(true)}
          onOpenAiModal={() => setShowAiModal(true)}
        />

        {/* Horizontal Category Scroll Bar (Quick Mobile Thumb Navigation) */}
        <div className="flex items-center gap-1.5 px-3 py-2 bg-white border-b border-slate-200/80 overflow-x-auto no-scrollbar shrink-0 text-xs">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                sounds.playClick();
                if (cat.id === 'all') handleSelectMode('endless');
                else handleSelectMode('category', cat.nameHi);
              }}
              className={`px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition-all ${
                (cat.id === 'all' && currentMode === 'endless') || (selectedCategory === cat.nameHi && currentMode === 'category')
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.nameHi.split('(')[0].trim()}
            </button>
          ))}
        </div>

        {/* Mobile Main Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3 pb-24">
          {/* Quick 1-Click APK Download / Install Action Bar */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-2xl p-3 shadow-md flex items-center justify-between gap-2.5">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-white/20 text-white flex items-center justify-center shrink-0">
                <Download className="w-4 h-4 animate-bounce" />
              </div>
              <div className="min-w-0">
                <span className="font-extrabold text-xs block leading-tight truncate">
                  Smart GK Android App
                </span>
                <span className="text-[10px] text-emerald-100 block leading-tight">
                  फ़ोन में डायरेक्ट इंस्टॉल व APK
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                sounds.playClick();
                setShowInstallModal(true);
              }}
              className="bg-white hover:bg-emerald-50 text-emerald-950 font-extrabold text-[11px] px-3 py-1.5 rounded-xl shadow-xs shrink-0 flex items-center gap-1 active:scale-95 transition-all"
            >
              <span>इंस्टॉल करें</span>
              <Download className="w-3 h-3 text-emerald-700" />
            </button>
          </div>
          {/* Speed Mode Live Countdown Bar */}
          {currentMode === 'speed' && (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-2.5 flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2 text-rose-800 font-bold text-xs">
                <Zap className="w-4 h-4 text-rose-600 animate-pulse" />
                <span>60s स्पीड टेस्ट चालू है!</span>
              </div>
              <div className="flex items-center gap-1 font-mono text-xs font-bold text-rose-700 bg-white px-2 py-0.5 rounded-md border border-rose-200">
                <Timer className="w-3.5 h-3.5" />
                <span>{speedTimer}s</span>
              </div>
            </div>
          )}

          {/* Custom AI Topic Badge */}
          {customTopicTitle && (
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-2.5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-purple-900 font-semibold truncate pr-2">
                <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                <span className="truncate">टॉपिक: {customTopicTitle}</span>
              </div>
              <button
                onClick={() => handleSelectMode('endless')}
                className="text-purple-700 hover:text-purple-900 font-bold text-[11px] underline shrink-0"
              >
                हटाएं
              </button>
            </div>
          )}

          {/* Active Quiz Card */}
          {currentQuestion && (
            <QuizCard
              key={currentQuestion.id}
              question={currentQuestion}
              questionNumber={currentIndex + 1}
              totalQuestions={currentMode === 'exam' ? activeQuestions.length : undefined}
              languageMode={languageMode}
              isBookmarked={stats.bookmarks.includes(currentQuestion.id)}
              onToggleBookmark={handleToggleBookmark}
              onAnswerSelected={handleAnswerSelected}
              onNextQuestion={handleNextQuestion}
              onSkipQuestion={handleSkipQuestion}
              onOpenAudiencePoll={() => setShowAudiencePoll(true)}
              onOpenAiGuru={() => setShowAiGuru(true)}
              autoAdvanceEnabled={autoAdvanceEnabled}
              onToggleAutoAdvance={handleToggleAutoAdvance}
              mode={currentMode}
            />
          )}

          {/* Quick Exam End button if in Exam Mode */}
          {currentMode === 'exam' && (
            <div className="flex justify-center pt-2">
              <button
                onClick={() => {
                  sounds.playClick();
                  handleFinishSession();
                }}
                className="text-xs font-bold text-indigo-700 hover:text-indigo-900 bg-indigo-50 border border-indigo-200 px-3 py-1.5 rounded-lg transition-colors"
              >
                टेस्ट समाप्त करें व परिणाम देखें
              </button>
            </div>
          )}
        </main>

        {/* Native Mobile Android Bottom Navigation Bar */}
        <MobileBottomNav
          currentMode={currentMode}
          onSelectMode={handleSelectMode}
          onOpenAddQuestionModal={() => setShowAddQuestionModal(true)}
          onOpenAdminDashboard={() => setShowAdminDashboard(true)}
        />
      </div>

      {/* Audience Poll Modal */}
      {showAudiencePoll && currentQuestion && (
        <AudiencePollModal
          question={currentQuestion}
          hiddenOptions={[]}
          onClose={() => setShowAudiencePoll(false)}
        />
      )}

      {/* AI Guru Deep-dive Modal */}
      {showAiGuru && currentQuestion && (
        <AiGuruModal
          question={currentQuestion}
          selectedOptionIndex={sessionAnswers[currentQuestion.id] ?? null}
          onClose={() => setShowAiGuru(false)}
        />
      )}

      {/* AI Custom Quiz Generator Modal */}
      {showAiModal && (
        <AiQuizModal
          onQuestionsGenerated={handleAiQuestionsGenerated}
          onClose={() => setShowAiModal(false)}
        />
      )}

      {/* Saved & Mistakes Modal */}
      {savedModalTab && (
        <SavedQuestionsModal
          initialTab={savedModalTab}
          bookmarkedQuestions={bookmarkedQuestions}
          mistakeQuestions={mistakeQuestions}
          onRemoveBookmark={(id) => handleToggleBookmark(id)}
          onRemoveMistake={(id) => {
            setStats((prev) => ({
              ...prev,
              mistakes: prev.mistakes.filter((mId) => mId !== id),
            }));
          }}
          onStartPractice={handleStartPracticeFromList}
          onClose={() => setSavedModalTab(null)}
        />
      )}

      {/* App Install & Direct Link Modal */}
      {showInstallModal && (
        <AppInstallModal
          deferredPrompt={deferredPrompt}
          onInstallNative={handleInstallNative}
          onClose={() => setShowInstallModal(false)}
        />
      )}

      {/* Custom Questions Manager / Add Study Notes Modal */}
      {showAddQuestionModal && (
        <AddQuestionModal
          customQuestions={customQuestions}
          onAddQuestion={handleAddCustomQuestion}
          onDeleteQuestion={handleDeleteCustomQuestion}
          onImportQuestions={handleImportCustomQuestions}
          onClose={() => setShowAddQuestionModal(false)}
        />
      )}

      {/* Google Play Store & APK Publishing Guide Modal */}
      {showPlayStoreGuide && (
        <PlayStoreGuideModal
          onClose={() => setShowPlayStoreGuide(false)}
        />
      )}

      {/* Master Developer Control Room & Analytics Dashboard */}
      {showAdminDashboard && (
        <AdminDashboardModal
          onClose={() => setShowAdminDashboard(false)}
        />
      )}

      {/* Student Doubt & Contact Developer Modal */}
      {showContactModal && (
        <ContactDeveloperModal
          onClose={() => setShowContactModal(false)}
        />
      )}

      {/* Session Summary Modal */}
      {summaryData && (
        <SummaryModal
          summary={summaryData}
          onRestart={() => {
            setSummaryData(null);
            setupQuestionsForMode(currentMode, selectedCategory);
          }}
          onGoHome={() => {
            setSummaryData(null);
            handleSelectMode('endless');
          }}
        />
      )}
    </div>
  );
}
