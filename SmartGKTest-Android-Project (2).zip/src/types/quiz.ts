export type Difficulty = 'easy' | 'medium' | 'hard';

export interface Question {
  id: string;
  category: string;
  questionHi: string;
  questionEn: string;
  optionsHi: string[];
  optionsEn: string[];
  correctIndex: number;
  explanationHi: string;
  explanationEn: string;
  difficulty: Difficulty;
  tag?: string;
}

export type QuizMode = 'endless' | 'speed' | 'category' | 'exam' | 'bookmarks' | 'mistakes' | 'ai-custom';
export type LanguageMode = 'hi' | 'en' | 'bilingual';

export interface UserStats {
  totalAnswered: number;
  correctAnswers: number;
  currentStreak: number;
  maxStreak: number;
  coins: number;
  bookmarks: string[]; // Question IDs
  mistakes: string[]; // Question IDs
}

export interface QuizSessionSummary {
  mode: QuizMode;
  categoryName?: string;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  score: number;
  accuracy: number;
  timeSpentSeconds: number;
  questions: Question[];
  userAnswers: { [questionId: string]: number }; // questionId -> selectedIndex
}
